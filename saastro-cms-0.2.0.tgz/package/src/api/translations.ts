/**
 * Translations API Handler
 * CRUD operations for i18n translation files (JSON/YAML).
 *
 * Routes:
 * - GET  /api/cms/translations         → list locales + all translation data
 * - GET  /api/cms/translations/:locale  → get nested translation data for one locale
 * - PUT  /api/cms/translations/:locale  → replace translation data for a locale
 */

import type { SaastroCMSConfig } from '../types.js';
import { guardCMSRequest } from './auth-guard.js';

type SaastroCMSLocals = {
  session: unknown;
  githubToken: string | null;
};

function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

/**
 * Resolve the absolute path to a translation file for local dev mode.
 * translationsPath is relative to the project root, NOT the content root.
 */
async function resolveLocalTranslationPath(
  config: SaastroCMSConfig,
  relativePath: string,
): Promise<string> {
  const { resolve, join } = await import('node:path');
  const contentRoot = config._localContentRoot!;
  const contentPath = config.github.contentPath ?? 'src/content';
  const projectRoot = resolve(contentRoot, ...Array(contentPath.split('/').length).fill('..'));
  return join(projectRoot, relativePath);
}

/**
 * Read a single translation file (local or GitHub) and parse it.
 * Returns the parsed nested object, or null if the file doesn't exist.
 */
async function readTranslationFile(
  locale: string,
  locals: { saastrocms: SaastroCMSLocals },
  config: SaastroCMSConfig,
): Promise<Record<string, unknown> | null> {
  const ext = config.i18n!.format === 'yaml' ? 'yaml' : 'json';
  const filePath = `${config.i18n!.translationsPath}/${locale}.${ext}`;

  try {
    let content: string;

    if (config._localContentRoot) {
      const fs = await import('node:fs/promises');
      const fullPath = await resolveLocalTranslationPath(config, filePath);
      content = await fs.readFile(fullPath, 'utf-8');
    } else {
      const branch = config.github.branch || 'main';
      const resp = await fetch(
        `https://api.github.com/repos/${config.github.owner}/${config.github.repo}/contents/${encodeURIComponent(filePath)}?ref=${branch}`,
        {
          headers: {
            Authorization: `Bearer ${locals.saastrocms.githubToken}`,
            Accept: 'application/vnd.github.v3+json',
            'User-Agent': 'SaastroCMS/1.0',
          },
        },
      );

      if (!resp.ok) return null;

      const fileData = (await resp.json()) as { content: string; type: string };
      if (fileData.type !== 'file') return null;

      const binary = atob(fileData.content.replace(/\n/g, ''));
      const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
      content = new TextDecoder('utf-8').decode(bytes);
    }

    if (config.i18n!.format === 'yaml') {
      const yaml = await import('js-yaml');
      return (yaml.load(content) as Record<string, unknown>) ?? {};
    }
    return (JSON.parse(content) as Record<string, unknown>) ?? {};
  } catch {
    return null;
  }
}

/**
 * GET /api/cms/translations
 * List available locales and return all translation data for every locale.
 */
async function handleListLocales(
  locals: { saastrocms: SaastroCMSLocals },
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!config.i18n) {
    return jsonResponse({ error: 'i18n_not_configured', message: 'i18n is not configured' }, 400);
  }

  const translations: Record<string, Record<string, unknown>> = {};
  for (const locale of config.i18n.locales) {
    const data = await readTranslationFile(locale, locals, config);
    translations[locale] = data ?? {};
  }

  return jsonResponse({
    locales: config.i18n.locales,
    defaultLocale: config.i18n.defaultLocale,
    translations,
  });
}

/**
 * GET /api/cms/translations/:locale
 * Read a translation file and return the full nested object.
 */
async function handleGetTranslations(
  locale: string,
  locals: { saastrocms: SaastroCMSLocals },
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!config.i18n) {
    return jsonResponse({ error: 'i18n_not_configured' }, 400);
  }

  if (!config.i18n.locales.includes(locale)) {
    return jsonResponse(
      { error: 'invalid_locale', message: `Locale "${locale}" is not configured` },
      400,
    );
  }

  const data = await readTranslationFile(locale, locals, config);
  if (!data) {
    return jsonResponse({ error: 'not_found', message: 'Translation file not found' }, 404);
  }

  return jsonResponse({ locale, data });
}

/**
 * PUT /api/cms/translations/:locale
 * Replace the full translation data for a locale.
 * Body: the complete nested translation JSON object.
 */
async function handleUpdateTranslations(
  request: Request,
  locale: string,
  locals: { saastrocms: SaastroCMSLocals },
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!config.i18n) {
    return jsonResponse({ error: 'i18n_not_configured' }, 400);
  }

  if (!config.i18n.locales.includes(locale)) {
    return jsonResponse(
      { error: 'invalid_locale', message: `Locale "${locale}" is not configured` },
      400,
    );
  }

  let incoming: Record<string, unknown>;
  try {
    incoming = (await request.json()) as Record<string, unknown>;
  } catch {
    return jsonResponse({ error: 'invalid_body', message: 'Request body must be valid JSON' }, 400);
  }

  if (typeof incoming !== 'object' || incoming === null || Array.isArray(incoming)) {
    return jsonResponse(
      { error: 'invalid_body', message: 'Request body must be a JSON object' },
      400,
    );
  }

  const ext = config.i18n.format === 'yaml' ? 'yaml' : 'json';
  const filePath = `${config.i18n.translationsPath}/${locale}.${ext}`;

  try {
    // Serialize the incoming data
    let newContent: string;
    if (config.i18n.format === 'yaml') {
      const yaml = await import('js-yaml');
      newContent = yaml.dump(incoming, { indent: 2, lineWidth: -1 });
    } else {
      newContent = JSON.stringify(incoming, null, 2) + '\n';
    }

    // Write
    if (config._localContentRoot) {
      const fs = await import('node:fs/promises');
      const { dirname } = await import('node:path');
      const fullPath = await resolveLocalTranslationPath(config, filePath);
      await fs.mkdir(dirname(fullPath), { recursive: true });
      await fs.writeFile(fullPath, newContent, 'utf-8');
    } else {
      // GitHub: need to read existing file to get SHA for update
      const branch = config.github.branch || 'main';
      const getResp = await fetch(
        `https://api.github.com/repos/${config.github.owner}/${config.github.repo}/contents/${encodeURIComponent(filePath)}?ref=${branch}`,
        {
          headers: {
            Authorization: `Bearer ${locals.saastrocms.githubToken}`,
            Accept: 'application/vnd.github.v3+json',
            'User-Agent': 'SaastroCMS/1.0',
          },
        },
      );

      let sha: string | undefined;
      if (getResp.ok) {
        const fileData = (await getResp.json()) as { sha: string };
        sha = fileData.sha;
      }

      const encodedContent = btoa(
        Array.from(new TextEncoder().encode(newContent))
          .map((b) => String.fromCharCode(b))
          .join(''),
      );

      const putBody: Record<string, unknown> = {
        message: `Update ${locale} translations`,
        content: encodedContent,
        branch,
      };
      if (sha) {
        putBody.sha = sha;
      }

      const putResp = await fetch(
        `https://api.github.com/repos/${config.github.owner}/${config.github.repo}/contents/${encodeURIComponent(filePath)}`,
        {
          method: 'PUT',
          headers: {
            Authorization: `Bearer ${locals.saastrocms.githubToken}`,
            Accept: 'application/vnd.github.v3+json',
            'Content-Type': 'application/json',
            'User-Agent': 'SaastroCMS/1.0',
          },
          body: JSON.stringify(putBody),
        },
      );
      if (!putResp.ok) {
        const err = (await putResp.json()) as { message?: string };
        throw new Error(err.message || `GitHub API error: ${putResp.status}`);
      }
    }

    return jsonResponse({ locale, data: incoming });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to update translations';
    return jsonResponse({ error: 'update_error', message }, 500);
  }
}

/**
 * Main router for translation requests.
 * Returns Response if matched, null if not a translations route.
 */
export async function handleTranslationsRequest(
  request: Request,
  locals: { saastrocms: SaastroCMSLocals },
  config: SaastroCMSConfig,
): Promise<Response | null> {
  const url = new URL(request.url);
  const path = url.pathname;

  // Validate this is actually a translations route before running auth —
  // auth errors on non-matching routes would mask routing issues.
  const isListRoute = path === '/api/cms/translations';
  const localeMatch = path.match(/^\/api\/cms\/translations\/([a-z]{2,5})$/);
  if (!isListRoute && !localeMatch) return null;

  // Auth guard — blocks CSRF + unauthenticated writes.
  const guard = guardCMSRequest(request, locals, config);
  if (!guard.allowed) return guard.response;

  if (isListRoute && request.method === 'GET') {
    return handleListLocales(locals, config);
  }

  if (!localeMatch) {
    return jsonResponse({ error: 'method_not_allowed' }, 405);
  }

  const locale = localeMatch[1]!;

  if (request.method === 'GET') {
    return handleGetTranslations(locale, locals, config);
  }

  if (request.method === 'PUT') {
    return handleUpdateTranslations(request, locale, locals, config);
  }

  return jsonResponse({ error: 'method_not_allowed' }, 405);
}
