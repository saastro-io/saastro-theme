/**
 * CMS Settings API Handler
 *
 * Routes:
 * - GET   /api/cms/settings      → get current CMS settings
 * - PUT   /api/cms/settings      → update CMS settings
 * - POST  /api/cms/settings/scan → scan pages + translations, return generated singletons
 */

import type { SaastroCMSConfig } from '../types.js';

type SaastroCMSLocals = {
  session: unknown;
  githubToken: string | null;
};

function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

/**
 * Resolve project root from config.
 */
async function resolveProjectRoot(config: SaastroCMSConfig): Promise<string> {
  const { resolve } = await import('node:path');
  const contentRoot = config._localContentRoot!;
  const contentPath = config.github.contentPath ?? 'src/content';
  return resolve(contentRoot, ...Array(contentPath.split('/').length).fill('..'));
}

/**
 * Read .saastrocms/settings.json from project root.
 */
async function readSettings(projectRoot: string): Promise<Record<string, unknown>> {
  const { join } = await import('node:path');
  const { readFile } = await import('node:fs/promises');
  const settingsPath = join(projectRoot, '.saastrocms', 'settings.json');
  try {
    const content = await readFile(settingsPath, 'utf-8');
    return JSON.parse(content) as Record<string, unknown>;
  } catch {
    return {};
  }
}

/**
 * Write .saastrocms/settings.json to project root.
 */
async function writeSettings(
  projectRoot: string,
  settings: Record<string, unknown>,
): Promise<void> {
  const { join } = await import('node:path');
  const { writeFile, mkdir } = await import('node:fs/promises');
  const dir = join(projectRoot, '.saastrocms');
  await mkdir(dir, { recursive: true });
  await writeFile(join(dir, 'settings.json'), JSON.stringify(settings, null, 2));
}

/**
 * Scan pages and translations to generate singleton configs.
 */
async function handleScan(config: SaastroCMSConfig): Promise<Response> {
  if (!config._localContentRoot) {
    return jsonResponse(
      { error: 'not_supported', message: 'Scan is only available in dev mode' },
      400,
    );
  }

  if (!config.i18n) {
    return jsonResponse(
      { error: 'not_configured', message: 'i18n must be configured to scan pages' },
      400,
    );
  }

  try {
    const { join } = await import('node:path');
    const { readFile } = await import('node:fs/promises');
    const { scanPages } = await import('../page-scanner.js');
    const { generateTranslationSingletons } = await import('../translation-singletons.js');

    const projectRoot = await resolveProjectRoot(config);
    const pagesDir = join(projectRoot, 'src', 'pages');
    const translationsPath = config.i18n.translationsPath ?? 'src/i18n/translations';
    const defaultLocale = config.i18n.defaultLocale ?? 'en';
    const ext = config.i18n.format === 'yaml' ? 'yaml' : 'json';
    const translationFile = join(projectRoot, translationsPath, `${defaultLocale}.${ext}`);

    // Scan pages
    const pages = await scanPages(pagesDir);

    // Read default locale translations
    const translationContent = await readFile(translationFile, 'utf-8');
    const translations = JSON.parse(translationContent) as Record<string, unknown>;

    // Generate singletons
    const sharedPrefixes = config.i18n.sharedPrefixes ?? ['nav', 'footer', 'contactForm'];
    const singletons = generateTranslationSingletons(pages, translations, { sharedPrefixes });

    return jsonResponse({
      pages: pages.map((p) => ({
        slug: p.slug,
        fileName: p.fileName,
        sectionCount: p.sections.length,
        sections: p.sections,
      })),
      singletons,
      stats: {
        pagesScanned: pages.length,
        singletonsGenerated: Object.keys(singletons).length,
        totalFields: Object.values(singletons).reduce(
          (sum, s) => sum + (s.fields?.length ?? 0),
          0,
        ),
      },
    });
  } catch (error) {
    return jsonResponse(
      {
        error: 'scan_error',
        message: error instanceof Error ? error.message : 'Failed to scan pages',
      },
      500,
    );
  }
}

/**
 * GET /api/cms/settings
 */
async function handleGetSettings(config: SaastroCMSConfig): Promise<Response> {
  if (!config._localContentRoot) {
    return jsonResponse({ error: 'not_supported', message: 'Settings only available in dev mode' }, 400);
  }

  const projectRoot = await resolveProjectRoot(config);
  const settings = await readSettings(projectRoot);
  return jsonResponse({ settings });
}

/**
 * PUT /api/cms/settings
 */
async function handlePutSettings(
  request: Request,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!config._localContentRoot) {
    return jsonResponse({ error: 'not_supported', message: 'Settings only available in dev mode' }, 400);
  }

  try {
    const body = (await request.json()) as { settings: Record<string, unknown> };
    const projectRoot = await resolveProjectRoot(config);
    await writeSettings(projectRoot, body.settings);
    return jsonResponse({ saved: true });
  } catch (error) {
    return jsonResponse(
      { error: 'save_error', message: error instanceof Error ? error.message : 'Failed to save' },
      500,
    );
  }
}

/**
 * Route handler for settings API endpoints.
 */
export async function handleSettingsRequest(
  request: Request,
  _locals: { saastrocms: SaastroCMSLocals },
  config: SaastroCMSConfig,
): Promise<Response | null> {
  const url = new URL(request.url);
  const path = url.pathname;
  // Match /api/cms/settings or /api/cms/settings/scan (handle trailing slashes)
  const settingsPath = path.replace(/\/+$/, '');

  // POST /api/cms/settings/scan
  if (settingsPath.endsWith('/settings/scan') && request.method === 'POST') {
    return handleScan(config);
  }

  // GET/PUT /api/cms/settings
  if (settingsPath.endsWith('/settings') && !settingsPath.endsWith('/settings/scan')) {
    if (request.method === 'GET') return handleGetSettings(config);
    if (request.method === 'PUT') return handlePutSettings(request, config);
    return jsonResponse({ error: 'method_not_allowed' }, 405);
  }

  return null;
}
