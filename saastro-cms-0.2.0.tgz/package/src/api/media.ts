/**
 * SaastroCMS Media API Handlers
 * REST API for media upload, list, and delete operations
 */

import type { SaastroCMSLocals } from '../middleware.js';
import type { SaastroCMSConfig } from '../types.js';

type MediaItem = {
  name: string;
  path: string;
  url: string;
  /** Public URL path for use in content (e.g., "/images/vodafone/hero.png") */
  publicUrl: string;
  sha: string;
  size: number;
  type: string;
  isDirectory?: boolean;
};

/**
 * Create JSON response
 */
function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

/**
 * Get media path from config
 */
function getMediaPath(config: SaastroCMSConfig): string {
  return config.media?.pathPrefix ?? 'public/images';
}

/**
 * Compute public URL from a GitHub repo path.
 * Strips the "public" prefix so "public/images/brand/logo.svg" becomes "/images/brand/logo.svg"
 */
function toPublicUrl(repoPath: string): string {
  if (repoPath.startsWith('public/')) {
    return '/' + repoPath.slice('public/'.length);
  }
  return '/' + repoPath;
}

/**
 * Get file extension from filename
 */
function getExtension(filename: string): string {
  const parts = filename.split('.');
  return parts.length > 1 ? parts.pop()!.toLowerCase() : '';
}

/**
 * Get MIME type from extension
 */
function getMimeType(ext: string): string {
  const mimeTypes: Record<string, string> = {
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    png: 'image/png',
    gif: 'image/gif',
    webp: 'image/webp',
    svg: 'image/svg+xml',
    pdf: 'application/pdf',
    mp4: 'video/mp4',
    webm: 'video/webm',
  };
  return mimeTypes[ext] || 'application/octet-stream';
}

/**
 * Check if file type is allowed
 */
function isAllowedType(mimeType: string, config: SaastroCMSConfig): boolean {
  const allowed = config.media?.allowedTypes ?? [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml',
    'application/pdf',
    'video/mp4',
    'video/webm',
  ];
  return allowed.includes(mimeType);
}

/**
 * List media files (and directories)
 * GET /api/cms/media?subdir=brand
 */
export async function handleListMedia(
  request: Request,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  const mediaPath = getMediaPath(config);
  const url = new URL(request.url);
  const subdir = url.searchParams.get('subdir') || '';
  const browsePath = subdir ? `${mediaPath}/${subdir}` : mediaPath;
  const { owner, repo, branch = 'main' } = config.github;

  try {
    // Fetch directory contents from GitHub
    const response = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/contents/${browsePath}?ref=${branch}`,
      {
        headers: {
          Authorization: `Bearer ${locals.githubToken}`,
          Accept: 'application/vnd.github.v3+json',
          'User-Agent': 'SaastroCMS',
        },
      },
    );

    if (response.status === 404) {
      return jsonResponse({ items: [], subdir });
    }

    if (!response.ok) {
      const error = await response.text();
      console.error('[SaastroCMS] GitHub API error:', error);
      return jsonResponse({ error: 'github_error', message: 'Failed to list media' }, 500);
    }

    const contents = (await response.json()) as Array<{
      name: string;
      path: string;
      sha: string;
      size: number;
      download_url: string | null;
      type: string; // "file" or "dir"
    }>;

    const items: MediaItem[] = [];

    // Directories first
    for (const item of contents) {
      if (item.type === 'dir') {
        items.push({
          name: item.name,
          path: item.path,
          url: '',
          publicUrl: toPublicUrl(item.path),
          sha: item.sha,
          size: 0,
          type: 'directory',
          isDirectory: true,
        });
      }
    }

    // Then files (filtered by allowed types)
    for (const item of contents) {
      if (item.type === 'file') {
        const ext = getExtension(item.name);
        const mimeType = getMimeType(ext);
        if (isAllowedType(mimeType, config)) {
          items.push({
            name: item.name,
            path: item.path,
            url: item.download_url || '',
            publicUrl: toPublicUrl(item.path),
            sha: item.sha,
            size: item.size,
            type: mimeType,
          });
        }
      }
    }

    return jsonResponse({ items, subdir });
  } catch (error) {
    console.error('[SaastroCMS] Media list error:', error);
    return jsonResponse({ error: 'internal_error', message: 'Failed to list media' }, 500);
  }
}

/**
 * Upload media file
 * POST /api/cms/media
 */
export async function handleUploadMedia(
  request: Request,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;

    if (!file) {
      return jsonResponse({ error: 'validation_error', message: 'No file provided' }, 400);
    }

    // Check file size
    const maxSize = config.media?.maxSize ?? 5 * 1024 * 1024; // 5MB default
    if (file.size > maxSize) {
      return jsonResponse(
        {
          error: 'validation_error',
          message: `File too large. Max size: ${maxSize / 1024 / 1024}MB`,
        },
        400,
      );
    }

    // Check file type
    if (!isAllowedType(file.type, config)) {
      return jsonResponse({ error: 'validation_error', message: 'File type not allowed' }, 400);
    }

    // Generate unique filename
    const ext = getExtension(file.name);
    const baseName = file.name.replace(/\.[^.]+$/, '').replace(/[^a-z0-9-_]/gi, '-');
    const timestamp = Date.now();
    const filename = `${baseName}-${timestamp}.${ext}`;

    const mediaPath = getMediaPath(config);
    const subdir = formData.get('subdir') as string | null;
    const basePath = subdir ? `${mediaPath}/${subdir}` : mediaPath;
    const filePath = `${basePath}/${filename}`;
    const { owner, repo, branch = 'main' } = config.github;

    // Read file as base64
    const arrayBuffer = await file.arrayBuffer();
    const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));

    // Upload to GitHub
    const response = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`,
      {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${locals.githubToken}`,
          Accept: 'application/vnd.github.v3+json',
          'Content-Type': 'application/json',
          'User-Agent': 'SaastroCMS',
        },
        body: JSON.stringify({
          message: `Upload ${filename} via SaastroCMS`,
          content: base64,
          branch,
        }),
      },
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('[SaastroCMS] GitHub upload error:', error);
      return jsonResponse({ error: 'github_error', message: 'Failed to upload file' }, 500);
    }

    const result = (await response.json()) as {
      content: {
        name: string;
        path: string;
        sha: string;
        size: number;
        download_url: string;
      };
    };

    const item: MediaItem = {
      name: result.content.name,
      path: result.content.path,
      url: result.content.download_url,
      publicUrl: toPublicUrl(result.content.path),
      sha: result.content.sha,
      size: result.content.size,
      type: file.type,
    };

    return jsonResponse({ item }, 201);
  } catch (error) {
    console.error('[SaastroCMS] Media upload error:', error);
    return jsonResponse({ error: 'internal_error', message: 'Failed to upload file' }, 500);
  }
}

/**
 * Delete media file
 * DELETE /api/cms/media/:filename
 */
export async function handleDeleteMedia(
  request: Request,
  filename: string,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  try {
    // Parse SHA from request body
    const body = (await request.json()) as { sha: string };
    if (!body.sha) {
      return jsonResponse({ error: 'validation_error', message: 'SHA required' }, 400);
    }

    const mediaPath = getMediaPath(config);
    const filePath = `${mediaPath}/${filename}`;
    const { owner, repo, branch = 'main' } = config.github;

    // Delete from GitHub
    const response = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`,
      {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${locals.githubToken}`,
          Accept: 'application/vnd.github.v3+json',
          'Content-Type': 'application/json',
          'User-Agent': 'SaastroCMS',
        },
        body: JSON.stringify({
          message: `Delete ${filename} via SaastroCMS`,
          sha: body.sha,
          branch,
        }),
      },
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('[SaastroCMS] GitHub delete error:', error);
      return jsonResponse({ error: 'github_error', message: 'Failed to delete file' }, 500);
    }

    return jsonResponse({ deleted: true });
  } catch (error) {
    console.error('[SaastroCMS] Media delete error:', error);
    return jsonResponse({ error: 'internal_error', message: 'Failed to delete file' }, 500);
  }
}

/**
 * Create folder by uploading a .gitkeep sentinel file
 * POST /api/cms/media/folder { path: "brand/logos" }
 */
async function handleCreateFolder(
  request: Request,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  try {
    const body = (await request.json()) as { path?: string };
    const folderPath = body.path?.trim();

    if (!folderPath) {
      return jsonResponse({ error: 'validation_error', message: 'Folder path is required' }, 400);
    }

    const mediaPath = getMediaPath(config);
    const gitkeepPath = `${mediaPath}/${folderPath}/.gitkeep`;
    const { owner, repo, branch = 'main' } = config.github;

    const response = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/contents/${gitkeepPath}`,
      {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${locals.githubToken}`,
          Accept: 'application/vnd.github.v3+json',
          'Content-Type': 'application/json',
          'User-Agent': 'SaastroCMS',
        },
        body: JSON.stringify({
          message: `Create folder ${folderPath} via SaastroCMS`,
          content: '',
          branch,
        }),
      },
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('[SaastroCMS] GitHub create folder error:', error);
      return jsonResponse({ error: 'github_error', message: 'Failed to create folder' }, 500);
    }

    return jsonResponse({ created: true, path: folderPath }, 201);
  } catch (error) {
    console.error('[SaastroCMS] Create folder error:', error);
    return jsonResponse({ error: 'internal_error', message: 'Failed to create folder' }, 500);
  }
}

/**
 * Route handler for media API endpoints
 * Matches: /api/cms/media, /api/cms/media/folder, and /api/cms/media/:filename
 */
export async function handleMediaRequest(
  request: Request,
  locals: { saastrocms: SaastroCMSLocals },
  config: SaastroCMSConfig,
): Promise<Response | null> {
  const url = new URL(request.url);
  const path = url.pathname;

  // Match /api/cms/media/folder
  if (path === '/api/cms/media/folder' && request.method === 'POST') {
    return handleCreateFolder(request, locals.saastrocms, config);
  }

  // Match /api/cms/media/:filename?
  const match = path.match(/^\/api\/cms\/media(?:\/([^/]+))?$/);
  if (!match) {
    return null;
  }

  const filename = match[1] as string | undefined;
  const method = request.method;

  // Collection-level operations
  if (!filename) {
    if (method === 'GET') {
      return handleListMedia(request, locals.saastrocms, config);
    }
    if (method === 'POST') {
      return handleUploadMedia(request, locals.saastrocms, config);
    }
    return jsonResponse({ error: 'method_not_allowed', message: 'Method not allowed' }, 405);
  }

  // File-level operations
  if (method === 'DELETE') {
    return handleDeleteMedia(request, filename, locals.saastrocms, config);
  }

  return jsonResponse({ error: 'method_not_allowed', message: 'Method not allowed' }, 405);
}
