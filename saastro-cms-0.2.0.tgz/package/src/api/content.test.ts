/**
 * Tests for slug rename, check-slug, and YAML delete in content API
 */
import { beforeEach, describe, expect, it, vi } from 'vitest';

// Mock core/content before imports
vi.mock('@saastro/core/light', () => ({
  ContentError: class ContentError extends Error {
    code: string;
    status: number;
    details?: unknown;
    constructor(code: string, message: string, status: number, details?: unknown) {
      super(message);
      this.code = code;
      this.status = status;
      this.details = details;
    }
  },
  createFetchTransport: vi.fn(),
  createJsYamlParser: vi.fn(),
  createLightContentService: vi.fn(),
  createContentRequestSchema: { safeParse: vi.fn() },
  updateContentRequestSchema: { safeParse: vi.fn() },
}));

import { createLightContentService } from '@saastro/core/light';
import type { SaastroCMSLocals } from '../middleware.js';
import type { SaastroCMSConfig } from '../types.js';
import {
  handleCheckSlug,
  handleContentRequest,
  handleDeleteEntry,
  handleUpdateEntry,
} from './content.js';

const mockCreateContentService = vi.mocked(createLightContentService);

// --- Test helpers ---

const TEST_CONFIG: SaastroCMSConfig = {
  github: { owner: 'test-owner', repo: 'test-repo', branch: 'main', contentPath: 'src/content' },
};

// Simulates a signed-in user — the CSRF guard requires either a session or
// a dev-loopback request with matching Origin. Test requests below always
// set Origin via the helper, so this session is the authoritative allow.
const TEST_LOCALS: SaastroCMSLocals = {
  session: { userId: 'u', githubId: 1, githubUsername: 'u', email: 'u@test' } as unknown as SaastroCMSLocals['session'],
  githubToken: 'gh-test-token',
};

function makeRequest(url: string, opts: RequestInit = {}): Request {
  // Populate Origin header by default so the CSRF guard admits writes.
  const headers = new Headers(opts.headers);
  if (!headers.has('origin')) headers.set('origin', 'http://localhost');
  return new Request(`http://localhost${url}`, { ...opts, headers });
}

function jsonBody(data: unknown): RequestInit {
  return {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  };
}

/** Parse a JSON response body */
async function parseResponse(resp: Response) {
  return resp.json() as Promise<Record<string, unknown>>;
}

/** Set up fetch mock to return 404 for all paths by default */
function mockFetchDefault() {
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response('Not Found', { status: 404 })));
}

/** Build a GitHub Contents API success response */
function ghContentsResponse(data: Record<string, unknown>, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

/** Encode string to base64 (matching the module's encodeBase64) */
function toBase64(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary);
}

// --- Tests ---

describe('handleCheckSlug', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('returns 401 when not authenticated', async () => {
    const req = makeRequest('/api/cms/collections/tarifas/check-slug?slug=test');
    const resp = await handleCheckSlug(
      req,
      'tarifas',
      { session: null, githubToken: null },
      TEST_CONFIG,
    );
    expect(resp.status).toBe(401);
  });

  it('returns 400 when slug parameter is missing', async () => {
    const req = makeRequest('/api/cms/collections/tarifas/check-slug');
    const resp = await handleCheckSlug(req, 'tarifas', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(400);
    const body = await parseResponse(resp);
    expect(body.error).toBe('validation_error');
  });

  it('returns available:true when slug matches exclude (own slug)', async () => {
    const req = makeRequest(
      '/api/cms/collections/tarifas/check-slug?slug=my-entry&exclude=my-entry',
    );
    const resp = await handleCheckSlug(req, 'tarifas', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(200);
    const body = await parseResponse(resp);
    expect(body.available).toBe(true);
  });

  it('returns available:true when no file exists', async () => {
    mockFetchDefault();
    const req = makeRequest('/api/cms/collections/tarifas/check-slug?slug=new-entry');
    const resp = await handleCheckSlug(req, 'tarifas', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(200);
    const body = await parseResponse(resp);
    expect(body.available).toBe(true);
  });

  it('returns available:false when a YAML file exists', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation((url: string) => {
        if (url.includes('existing-entry.yaml')) {
          return Promise.resolve(ghContentsResponse({ name: 'existing-entry.yaml' }));
        }
        return Promise.resolve(new Response('Not Found', { status: 404 }));
      }),
    );

    const req = makeRequest('/api/cms/collections/tarifas/check-slug?slug=existing-entry');
    const resp = await handleCheckSlug(req, 'tarifas', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(200);
    const body = await parseResponse(resp);
    expect(body.available).toBe(false);
  });

  it('returns available:false when an MD file exists', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation((url: string) => {
        if (url.includes('post.md')) {
          return Promise.resolve(ghContentsResponse({ name: 'post.md' }));
        }
        return Promise.resolve(new Response('Not Found', { status: 404 }));
      }),
    );

    const req = makeRequest('/api/cms/collections/blog/check-slug?slug=post');
    const resp = await handleCheckSlug(req, 'blog', TEST_LOCALS, TEST_CONFIG);
    const body = await parseResponse(resp);
    expect(body.available).toBe(false);
  });
});

describe('handleUpdateEntry — slug rename', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('returns 401 when not authenticated', async () => {
    const req = makeRequest(
      '/api/cms/collections/tarifas/old-slug',
      jsonBody({ sha: 'abc', frontmatter: {}, newSlug: 'new-slug' }),
    );
    const resp = await handleUpdateEntry(
      req,
      'tarifas',
      'old-slug',
      { session: null, githubToken: null },
      TEST_CONFIG,
    );
    expect(resp.status).toBe(401);
  });

  it('returns 400 when sha or frontmatter missing on rename', async () => {
    // resolveFileExtension will need fetch mock (returns 404 → defaults to 'md')
    mockFetchDefault();

    const req = makeRequest(
      '/api/cms/collections/tarifas/old-slug',
      jsonBody({ newSlug: 'new-slug', frontmatter: { title: 'test' } }),
    );
    const resp = await handleUpdateEntry(req, 'tarifas', 'old-slug', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(400);
    const body = await parseResponse(resp);
    expect(body.error).toBe('validation_error');
  });

  it('returns 409 when new slug already exists', async () => {
    const fetchMock = vi.fn().mockImplementation((url: string) => {
      // resolveFileExtension: old-slug.yaml exists
      if (url.includes('old-slug.yaml') && !url.includes('DELETE')) {
        return Promise.resolve(
          ghContentsResponse({
            content: toBase64('title: test\n'),
            sha: 'old-sha',
            path: 'src/content/tarifas/old-slug.yaml',
          }),
        );
      }
      // Check new slug: new-slug.yaml exists (conflict)
      if (url.includes('new-slug.yaml')) {
        return Promise.resolve(ghContentsResponse({ name: 'new-slug.yaml' }));
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest(
      '/api/cms/collections/tarifas/old-slug',
      jsonBody({ sha: 'old-sha', frontmatter: { title: 'Test' }, newSlug: 'new-slug' }),
    );
    const resp = await handleUpdateEntry(req, 'tarifas', 'old-slug', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(409);
    const body = await parseResponse(resp);
    expect(body.error).toBe('conflict');
    expect(body.message as string).toContain('new-slug');
  });

  it('renames a YAML entry: creates new file and deletes old', async () => {
    const fetchCalls: string[] = [];

    const fetchMock = vi.fn().mockImplementation((url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET';
      fetchCalls.push(`${method} ${url}`);

      // resolveFileExtension: old-slug.yaml exists
      if (url.includes('old-slug.yaml') && method === 'GET') {
        return Promise.resolve(
          ghContentsResponse({
            content: toBase64('title: test\n'),
            sha: 'old-sha',
            path: 'src/content/tarifas/old-slug.yaml',
          }),
        );
      }
      // Check new-slug doesn't exist (all 404)
      if (url.includes('new-slug') && method === 'GET') {
        return Promise.resolve(new Response('Not Found', { status: 404 }));
      }
      // Create new file (PUT new-slug.yaml)
      if (url.includes('new-slug.yaml') && method === 'PUT') {
        return Promise.resolve(
          ghContentsResponse({
            content: { sha: 'new-sha', path: 'src/content/tarifas/new-slug.yaml' },
          }),
        );
      }
      // Delete old file (DELETE old-slug.yaml)
      if (url.includes('old-slug.yaml') && method === 'DELETE') {
        return Promise.resolve(ghContentsResponse({ deleted: true }));
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest(
      '/api/cms/collections/tarifas/old-slug',
      jsonBody({
        sha: 'old-sha',
        frontmatter: { title: 'Test Entry', slug: 'new-slug' },
        newSlug: 'new-slug',
      }),
    );
    const resp = await handleUpdateEntry(req, 'tarifas', 'old-slug', TEST_LOCALS, TEST_CONFIG);
    const body = await parseResponse(resp);

    expect(resp.status).toBe(200);
    expect(body.renamed).toBe(true);
    expect((body.entry as Record<string, unknown>).slug).toBe('new-slug');
    expect((body.entry as Record<string, unknown>).sha).toBe('new-sha');

    // Verify a PUT (create) and a DELETE happened
    const putCalls = fetchCalls.filter((c) => c.startsWith('PUT') && c.includes('new-slug'));
    const deleteCalls = fetchCalls.filter((c) => c.startsWith('DELETE') && c.includes('old-slug'));
    expect(putCalls.length).toBeGreaterThan(0);
    expect(deleteCalls.length).toBeGreaterThan(0);
  });

  it('returns partial success when delete-old fails after create', async () => {
    const fetchMock = vi.fn().mockImplementation((url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET';

      // resolveFileExtension: old-slug.yaml
      if (url.includes('old-slug.yaml') && method === 'GET') {
        return Promise.resolve(
          ghContentsResponse({
            content: toBase64('title: test\n'),
            sha: 'old-sha',
            path: 'src/content/tarifas/old-slug.yaml',
          }),
        );
      }
      // Check new-slug doesn't exist
      if (url.includes('new-slug') && method === 'GET') {
        return Promise.resolve(new Response('Not Found', { status: 404 }));
      }
      // Create new file — success
      if (url.includes('new-slug.yaml') && method === 'PUT') {
        return Promise.resolve(
          ghContentsResponse({
            content: { sha: 'new-sha', path: 'src/content/tarifas/new-slug.yaml' },
          }),
        );
      }
      // Delete old file — FAIL (409 conflict)
      if (url.includes('old-slug.yaml') && method === 'DELETE') {
        return Promise.resolve(
          new Response(JSON.stringify({ message: 'SHA mismatch' }), { status: 409 }),
        );
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest(
      '/api/cms/collections/tarifas/old-slug',
      jsonBody({
        sha: 'old-sha',
        frontmatter: { title: 'Test' },
        newSlug: 'new-slug',
      }),
    );
    const resp = await handleUpdateEntry(req, 'tarifas', 'old-slug', TEST_LOCALS, TEST_CONFIG);
    const body = await parseResponse(resp);

    // Should still succeed (partial) — new file was created
    expect(resp.status).toBe(200);
    expect(body.renamed).toBe(true);
    expect(body.deleteOldFailed).toBe(true);
    expect((body.entry as Record<string, unknown>).slug).toBe('new-slug');
  });

  it('skips rename when newSlug equals current slug', async () => {
    // Should fall through to normal update logic
    const yamlContent = toBase64('title: test\n');
    const fetchMock = vi.fn().mockImplementation((url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET';
      // resolveFileExtension: same-slug.yaml
      if (url.includes('same-slug.yaml') && method === 'GET') {
        return Promise.resolve(
          ghContentsResponse({
            content: yamlContent,
            sha: 'current-sha',
            path: 'src/content/tarifas/same-slug.yaml',
          }),
        );
      }
      // Normal update
      if (url.includes('same-slug.yaml') && method === 'PUT') {
        return Promise.resolve(
          ghContentsResponse({
            content: { sha: 'updated-sha', path: 'src/content/tarifas/same-slug.yaml' },
          }),
        );
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest(
      '/api/cms/collections/tarifas/same-slug',
      jsonBody({
        sha: 'current-sha',
        frontmatter: { title: 'Updated' },
        newSlug: 'same-slug',
      }),
    );
    const resp = await handleUpdateEntry(req, 'tarifas', 'same-slug', TEST_LOCALS, TEST_CONFIG);
    const body = await parseResponse(resp);

    expect(resp.status).toBe(200);
    // Should NOT have renamed flag — just a normal update
    expect(body.renamed).toBeUndefined();
    expect((body.entry as Record<string, unknown>).slug).toBe('same-slug');
  });
});

describe('handleDeleteEntry — format-aware', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('returns 401 when not authenticated', async () => {
    const req = makeRequest('/api/cms/collections/tarifas/entry', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sha: 'abc' }),
    });
    const resp = await handleDeleteEntry(
      req,
      'tarifas',
      'entry',
      { session: null, githubToken: null },
      TEST_CONFIG,
    );
    expect(resp.status).toBe(401);
  });

  it('returns 400 when sha is missing', async () => {
    const req = makeRequest('/api/cms/collections/tarifas/entry', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
    const resp = await handleDeleteEntry(req, 'tarifas', 'entry', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(400);
  });

  it('deletes a YAML entry via GitHub Contents API', async () => {
    let deleteCalled = false;
    const fetchMock = vi.fn().mockImplementation((url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET';
      // resolveFileExtension: entry.yaml exists
      if (url.includes('entry.yaml') && method === 'GET') {
        return Promise.resolve(ghContentsResponse({ name: 'entry.yaml' }));
      }
      // DELETE entry.yaml
      if (url.includes('entry.yaml') && method === 'DELETE') {
        deleteCalled = true;
        return Promise.resolve(ghContentsResponse({ deleted: true }));
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest('/api/cms/collections/tarifas/entry', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sha: 'file-sha' }),
    });
    const resp = await handleDeleteEntry(req, 'tarifas', 'entry', TEST_LOCALS, TEST_CONFIG);
    const body = await parseResponse(resp);

    expect(resp.status).toBe(200);
    expect(body.deleted).toBe(true);
    expect(deleteCalled).toBe(true);
  });

  it('deletes an MD entry via core service', async () => {
    mockFetchDefault(); // All 404 → resolves to 'md'

    const mockService = {
      delete: vi.fn().mockResolvedValue({ success: true, data: {} }),
      list: vi.fn(),
      get: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
    };
    mockCreateContentService.mockReturnValue(mockService as never);

    const req = makeRequest('/api/cms/collections/blog/my-post', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sha: 'md-sha' }),
    });
    const resp = await handleDeleteEntry(req, 'blog', 'my-post', TEST_LOCALS, TEST_CONFIG);
    const body = await parseResponse(resp);

    expect(resp.status).toBe(200);
    expect(body.deleted).toBe(true);
    expect(mockService.delete).toHaveBeenCalledWith({
      collection: 'blog',
      slug: 'my-post',
      sha: 'md-sha',
    });
  });
});

describe('handleContentRequest — check-slug route', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('routes GET /api/cms/collections/:collection/check-slug to handleCheckSlug', async () => {
    mockFetchDefault();
    const req = makeRequest('/api/cms/collections/tarifas/check-slug?slug=test-slug');
    const resp = await handleContentRequest(req, { saastrocms: TEST_LOCALS }, TEST_CONFIG);
    expect(resp).not.toBeNull();
    expect(resp!.status).toBe(200);
    const body = await parseResponse(resp!);
    expect(body.available).toBe(true);
  });

  it('returns 405 for POST to check-slug', async () => {
    const req = makeRequest('/api/cms/collections/tarifas/check-slug?slug=test', {
      method: 'POST',
    });
    const resp = await handleContentRequest(req, { saastrocms: TEST_LOCALS }, TEST_CONFIG);
    expect(resp).not.toBeNull();
    expect(resp!.status).toBe(405);
  });
});

// --- New tests: handleUpdateEntry — SHA conflict & frontmatter update ---

describe('handleUpdateEntry — SHA conflict detection', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('returns 409 when YAML update has SHA mismatch', async () => {
    const fetchMock = vi.fn().mockImplementation((url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET';
      // resolveFileExtension: entry.yaml exists
      if (url.includes('entry.yaml') && method === 'GET') {
        return Promise.resolve(
          ghContentsResponse({
            content: toBase64('title: original\n'),
            sha: 'current-sha',
            path: 'src/content/tarifas/entry.yaml',
          }),
        );
      }
      // PUT fails with 409 (SHA mismatch)
      if (url.includes('entry.yaml') && method === 'PUT') {
        return Promise.resolve(
          new Response(JSON.stringify({ message: 'SHA does not match - 409' }), { status: 409 }),
        );
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest(
      '/api/cms/collections/tarifas/entry',
      jsonBody({ sha: 'stale-sha', frontmatter: { title: 'Updated' } }),
    );
    const resp = await handleUpdateEntry(req, 'tarifas', 'entry', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(409);
    const body = await parseResponse(resp);
    expect(body.error).toBe('conflict');
    expect(body.message).toContain('modified');
  });

  it('updates a YAML entry with valid SHA', async () => {
    const fetchMock = vi.fn().mockImplementation((url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET';
      // resolveFileExtension: entry.yaml exists
      if (url.includes('entry.yaml') && method === 'GET') {
        return Promise.resolve(
          ghContentsResponse({
            content: toBase64('title: old\n'),
            sha: 'valid-sha',
            path: 'src/content/tarifas/entry.yaml',
          }),
        );
      }
      // PUT succeeds
      if (url.includes('entry.yaml') && method === 'PUT') {
        return Promise.resolve(
          ghContentsResponse({
            content: { sha: 'new-sha', path: 'src/content/tarifas/entry.yaml' },
          }),
        );
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest(
      '/api/cms/collections/tarifas/entry',
      jsonBody({ sha: 'valid-sha', frontmatter: { title: 'Updated Title' } }),
    );
    const resp = await handleUpdateEntry(req, 'tarifas', 'entry', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(200);
    const body = await parseResponse(resp);
    expect((body.entry as Record<string, unknown>).sha).toBe('new-sha');
    expect((body.entry as Record<string, unknown>).slug).toBe('entry');
    expect(body.renamed).toBeUndefined();
  });

  it('returns 400 when sha is missing on YAML update (no rename)', async () => {
    const fetchMock = vi.fn().mockImplementation((url: string) => {
      // resolveFileExtension: entry.yaml exists
      if (url.includes('entry.yaml')) {
        return Promise.resolve(
          ghContentsResponse({
            content: toBase64('title: test\n'),
            sha: 'abc',
            path: 'src/content/tarifas/entry.yaml',
          }),
        );
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest(
      '/api/cms/collections/tarifas/entry',
      jsonBody({ frontmatter: { title: 'test' } }),
    );
    const resp = await handleUpdateEntry(req, 'tarifas', 'entry', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(400);
    const body = await parseResponse(resp);
    expect(body.error).toBe('validation_error');
  });

  it('returns 400 when frontmatter is missing on YAML update (no rename)', async () => {
    const fetchMock = vi.fn().mockImplementation((url: string) => {
      if (url.includes('entry.yaml')) {
        return Promise.resolve(
          ghContentsResponse({
            content: toBase64('title: test\n'),
            sha: 'abc',
            path: 'src/content/tarifas/entry.yaml',
          }),
        );
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest(
      '/api/cms/collections/tarifas/entry',
      jsonBody({ sha: 'abc' }),
    );
    const resp = await handleUpdateEntry(req, 'tarifas', 'entry', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(400);
    const body = await parseResponse(resp);
    expect(body.error).toBe('validation_error');
  });

  it('updates an MD entry via core service', async () => {
    mockFetchDefault(); // All 404 → resolves to 'md'

    const mockService = {
      list: vi.fn(),
      get: vi.fn(),
      create: vi.fn(),
      update: vi.fn().mockResolvedValue({
        success: true,
        data: {
          slug: 'my-post',
          collection: 'blog',
          path: 'src/content/blog/my-post.md',
          sha: 'updated-sha',
          frontmatter: { title: 'Updated Post' },
          body: 'New content',
        },
      }),
      delete: vi.fn(),
    };
    mockCreateContentService.mockReturnValue(mockService as never);

    // updateContentRequestSchema must pass validation
    const { updateContentRequestSchema } = await import('@saastro/core/light');
    vi.mocked(updateContentRequestSchema.safeParse).mockReturnValue({
      success: true,
      data: {
        sha: 'old-sha',
        frontmatter: { title: 'Updated Post' },
        body: 'New content',
      },
    } as never);

    const req = makeRequest(
      '/api/cms/collections/blog/my-post',
      jsonBody({ sha: 'old-sha', frontmatter: { title: 'Updated Post' }, body: 'New content' }),
    );
    const resp = await handleUpdateEntry(req, 'blog', 'my-post', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(200);
    const body = await parseResponse(resp);
    expect((body.entry as Record<string, unknown>).slug).toBe('my-post');
    expect(mockService.update).toHaveBeenCalledWith({
      collection: 'blog',
      slug: 'my-post',
      sha: 'old-sha',
      frontmatter: { title: 'Updated Post' },
      body: 'New content',
    });
  });

  it('returns 500 on internal YAML update error', async () => {
    const fetchMock = vi.fn().mockImplementation((url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET';
      if (url.includes('entry.yaml') && method === 'GET') {
        return Promise.resolve(
          ghContentsResponse({
            content: toBase64('title: test\n'),
            sha: 'valid-sha',
            path: 'src/content/tarifas/entry.yaml',
          }),
        );
      }
      // PUT fails with 500
      if (url.includes('entry.yaml') && method === 'PUT') {
        return Promise.resolve(
          new Response(JSON.stringify({ message: 'Internal Server Error' }), { status: 500 }),
        );
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest(
      '/api/cms/collections/tarifas/entry',
      jsonBody({ sha: 'valid-sha', frontmatter: { title: 'Test' } }),
    );
    const resp = await handleUpdateEntry(req, 'tarifas', 'entry', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(500);
    const body = await parseResponse(resp);
    expect(body.error).toBe('internal_error');
  });
});

// --- New tests: handleDeleteEntry — additional cases ---

describe('handleDeleteEntry — error handling', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('returns 500 when YAML delete fails with SHA mismatch', async () => {
    const fetchMock = vi.fn().mockImplementation((url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET';
      // resolveFileExtension: entry.yaml exists
      if (url.includes('entry.yaml') && method === 'GET') {
        return Promise.resolve(ghContentsResponse({ name: 'entry.yaml' }));
      }
      // DELETE fails with 409
      if (url.includes('entry.yaml') && method === 'DELETE') {
        return Promise.resolve(
          new Response(JSON.stringify({ message: 'SHA mismatch' }), { status: 409 }),
        );
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest('/api/cms/collections/tarifas/entry', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sha: 'wrong-sha' }),
    });
    const resp = await handleDeleteEntry(req, 'tarifas', 'entry', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(500);
    const body = await parseResponse(resp);
    expect(body.error).toBe('internal_error');
    expect(body.message).toContain('SHA mismatch');
  });

  it('deletes an MDX entry via GitHub Contents API', async () => {
    let deleteCalled = false;
    const fetchMock = vi.fn().mockImplementation((url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET';
      // resolveFileExtension: entry.mdx exists
      if (url.includes('entry.mdx') && method === 'GET') {
        return Promise.resolve(ghContentsResponse({ name: 'entry.mdx' }));
      }
      // DELETE entry.mdx
      if (url.includes('entry.mdx') && method === 'DELETE') {
        deleteCalled = true;
        return Promise.resolve(ghContentsResponse({ deleted: true }));
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest('/api/cms/collections/blog/entry', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sha: 'mdx-sha' }),
    });
    const resp = await handleDeleteEntry(req, 'blog', 'entry', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(200);
    const body = await parseResponse(resp);
    expect(body.deleted).toBe(true);
    expect(deleteCalled).toBe(true);
  });

  it('returns 500 when MD delete via core service fails', async () => {
    mockFetchDefault(); // All 404 → resolves to 'md'

    const mockService = {
      list: vi.fn(),
      get: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
      delete: vi.fn().mockResolvedValue({
        success: false,
        error: {
          code: 'not_found',
          message: 'Entry not found',
          status: 404,
        },
      }),
    };
    mockCreateContentService.mockReturnValue(mockService as never);

    const req = makeRequest('/api/cms/collections/blog/missing-post', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sha: 'some-sha' }),
    });
    const resp = await handleDeleteEntry(req, 'blog', 'missing-post', TEST_LOCALS, TEST_CONFIG);
    // Core service returns error response (not_found via errorResponse)
    expect(resp.status).toBe(404);
    const body = await parseResponse(resp);
    expect(body.error).toBe('not_found');
  });
});

// --- New tests: handleCheckSlug — MDX detection ---

describe('handleCheckSlug — additional formats', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('returns available:false when an MDX file exists', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation((url: string) => {
        if (url.includes('my-post.mdx')) {
          return Promise.resolve(ghContentsResponse({ name: 'my-post.mdx' }));
        }
        return Promise.resolve(new Response('Not Found', { status: 404 }));
      }),
    );

    const req = makeRequest('/api/cms/collections/blog/check-slug?slug=my-post');
    const resp = await handleCheckSlug(req, 'blog', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(200);
    const body = await parseResponse(resp);
    expect(body.available).toBe(false);
  });

  it('returns available:true when exclude matches and file actually exists', async () => {
    // Even if the file exists on disk, exclude short-circuits to available:true
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation((url: string) => {
        if (url.includes('current.yaml')) {
          return Promise.resolve(ghContentsResponse({ name: 'current.yaml' }));
        }
        return Promise.resolve(new Response('Not Found', { status: 404 }));
      }),
    );

    const req = makeRequest(
      '/api/cms/collections/tarifas/check-slug?slug=current&exclude=current',
    );
    const resp = await handleCheckSlug(req, 'tarifas', TEST_LOCALS, TEST_CONFIG);
    expect(resp.status).toBe(200);
    const body = await parseResponse(resp);
    expect(body.available).toBe(true);
  });
});

// --- New tests: handleContentRequest routing for update & delete ---

describe('handleContentRequest — update and delete routing', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('routes PUT /api/cms/collections/:collection/:slug to handleUpdateEntry', async () => {
    const yamlContent = toBase64('title: test\n');
    const fetchMock = vi.fn().mockImplementation((url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET';
      if (url.includes('my-entry.yaml') && method === 'GET') {
        return Promise.resolve(
          ghContentsResponse({
            content: yamlContent,
            sha: 'current-sha',
            path: 'src/content/tarifas/my-entry.yaml',
          }),
        );
      }
      if (url.includes('my-entry.yaml') && method === 'PUT') {
        return Promise.resolve(
          ghContentsResponse({
            content: { sha: 'updated-sha', path: 'src/content/tarifas/my-entry.yaml' },
          }),
        );
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest(
      '/api/cms/collections/tarifas/my-entry',
      jsonBody({ sha: 'current-sha', frontmatter: { title: 'Updated' } }),
    );
    const resp = await handleContentRequest(req, { saastrocms: TEST_LOCALS }, TEST_CONFIG);
    expect(resp).not.toBeNull();
    expect(resp!.status).toBe(200);
    const body = await parseResponse(resp!);
    expect((body.entry as Record<string, unknown>).sha).toBe('updated-sha');
  });

  it('routes DELETE /api/cms/collections/:collection/:slug to handleDeleteEntry', async () => {
    let deleteCalled = false;
    const fetchMock = vi.fn().mockImplementation((url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET';
      if (url.includes('doomed.yaml') && method === 'GET') {
        return Promise.resolve(ghContentsResponse({ name: 'doomed.yaml' }));
      }
      if (url.includes('doomed.yaml') && method === 'DELETE') {
        deleteCalled = true;
        return Promise.resolve(ghContentsResponse({ deleted: true }));
      }
      return Promise.resolve(new Response('Not Found', { status: 404 }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const req = makeRequest('/api/cms/collections/tarifas/doomed', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sha: 'file-sha' }),
    });
    const resp = await handleContentRequest(req, { saastrocms: TEST_LOCALS }, TEST_CONFIG);
    expect(resp).not.toBeNull();
    expect(resp!.status).toBe(200);
    const body = await parseResponse(resp!);
    expect(body.deleted).toBe(true);
    expect(deleteCalled).toBe(true);
  });
});
