/**
 * CMS API auth/CSRF guard.
 *
 * Blocks unauthenticated writes and cross-origin requests to the CMS API.
 * Applied uniformly to translations, content, media, and dev-only endpoints.
 *
 * Three layers:
 *
 * 1. **Session check** — writes require either a valid session in locals
 *    OR an explicit dev-mode escape (only when running from a local root
 *    AND the request originates from the same host). Reads are unrestricted
 *    so public sites can still fetch published data.
 *
 * 2. **Same-origin check (CSRF)** — non-GET/HEAD requests must carry an
 *    `Origin` header matching the request `Host`. Stops drive-by cross-site
 *    POSTs even when credentials are auto-sent by the browser.
 *
 * 3. **Loopback guard (dev only)** — when there is no session AND we are in
 *    local-filesystem mode, only requests whose Host is localhost/127.0.0.1
 *    are allowed to proceed unauthenticated. This keeps single-user dev
 *    ergonomic without exposing the writer to LAN peers.
 */

import type { SaastroCMSConfig } from '../types.js';

export type SaastroCMSLocals = {
  session: unknown;
  githubToken: string | null;
};

export type GuardResult = { allowed: true } | { allowed: false; response: Response };

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);
const LOOPBACK_HOSTS = new Set([
  'localhost',
  '127.0.0.1',
  '[::1]',
  '::1',
  '0.0.0.0',
  'hub.saastro.test',
]);

function jsonError(status: number, code: string, message: string): Response {
  return new Response(JSON.stringify({ error: code, message }), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function isLoopbackHost(host: string | null | undefined): boolean {
  if (!host) return false;
  const bareHost = host.split(':')[0] ?? '';
  if (LOOPBACK_HOSTS.has(bareHost)) return true;
  if (bareHost.endsWith('.localhost')) return true;
  if (bareHost.endsWith('.saastro.test')) return true;
  return false;
}

function sameOrigin(origin: string | null, host: string | null): boolean {
  if (!origin || !host) return false;
  try {
    const originUrl = new URL(origin);
    return originUrl.host === host;
  } catch {
    return false;
  }
}

/**
 * Standard Request objects don't expose a Host header — it's derived from
 * the request URL at transport time. Read it from the URL so same-origin
 * checks still work in both Workers (where .headers.host may be absent)
 * and tests that construct synthetic Request instances.
 */
function resolveHost(request: Request): string | null {
  const headerHost = request.headers.get('host');
  if (headerHost) return headerHost;
  try {
    return new URL(request.url).host;
  } catch {
    return null;
  }
}

/**
 * Gate a CMS API request. Returns `{ allowed: true }` when the request may
 * proceed, or `{ allowed: false, response }` with a ready-to-return error.
 *
 * Safe (GET/HEAD) reads are always allowed — sites need to fetch published
 * content. Writes require both same-origin and a session (or dev loopback).
 */
export function guardCMSRequest(
  request: Request,
  locals: { saastrocms: SaastroCMSLocals },
  config: SaastroCMSConfig,
): GuardResult {
  const method = request.method.toUpperCase();
  if (SAFE_METHODS.has(method)) return { allowed: true };

  const origin = request.headers.get('origin');
  const host = resolveHost(request);

  // CSRF: every write must be same-origin.
  if (!sameOrigin(origin, host)) {
    return {
      allowed: false,
      response: jsonError(
        403,
        'forbidden_origin',
        'Cross-origin writes are not allowed. Include a matching Origin header.',
      ),
    };
  }

  // Authenticated session → allow.
  if (locals.saastrocms.session) return { allowed: true };

  // Dev escape: only permitted when (a) the CMS is running against a local
  // filesystem (single-developer session) AND (b) the request comes from a
  // loopback host. Anything else must authenticate.
  const isDevLocal = Boolean(config._localContentRoot);
  if (isDevLocal && isLoopbackHost(host)) return { allowed: true };

  return {
    allowed: false,
    response: jsonError(
      401,
      'unauthenticated',
      'Authentication required for CMS writes.',
    ),
  };
}

/**
 * Constant-time string comparison for secrets that travel in headers/cookies.
 * Prevents leaking length via early-exit comparisons.
 */
export function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}
