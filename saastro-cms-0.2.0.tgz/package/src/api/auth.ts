/**
 * SaastroCMS Authentication API Handlers
 * Handles OAuth flow with GitHub
 */

import {
  DEFAULT_SESSION_TTL,
  type OAuthConfig,
  type SessionData,
  type SessionStorage,
  completeOAuthFlow,
  createClearSessionCookie,
  createSessionCookie,
  createSessionData,
  deleteSession,
  generateSessionId,
  generateState,
  getAuthorizationUrl,
  parseSessionCookie,
  storeSession,
} from '@saastro/core/auth';
import type { CloudflareEnv } from '../types.js';

/**
 * State storage key prefix
 */
const STATE_KEY_PREFIX = 'oauth_state:';

/**
 * State TTL: 10 minutes
 */
const STATE_TTL = 600;

/**
 * Create a KV-compatible session storage from Cloudflare KV
 */
function createKVStorage(kv: KVNamespace): SessionStorage {
  return {
    async get(key: string): Promise<SessionData | null> {
      const data = await kv.get(key, 'json');
      return data as SessionData | null;
    },
    async put(
      key: string,
      value: SessionData,
      options?: { expirationTtl?: number },
    ): Promise<void> {
      await kv.put(key, JSON.stringify(value), {
        expirationTtl: options?.expirationTtl,
      });
    },
    async delete(key: string): Promise<void> {
      await kv.delete(key);
    },
  };
}

/**
 * Get OAuth config from environment
 */
function getOAuthConfig(env: CloudflareEnv, redirectUri: string): OAuthConfig {
  return {
    clientId: env.GITHUB_CLIENT_ID,
    clientSecret: env.GITHUB_CLIENT_SECRET,
    redirectUri,
  };
}

/**
 * Login handler - Redirects to GitHub OAuth
 */
export async function handleLogin(request: Request, env: CloudflareEnv): Promise<Response> {
  const url = new URL(request.url);
  const redirectTo = url.searchParams.get('redirect') || '/admin';

  // Generate and store state for CSRF protection
  const state = generateState();
  const stateData = {
    redirectTo,
    createdAt: Date.now(),
  };

  await env.KV.put(`${STATE_KEY_PREFIX}${state}`, JSON.stringify(stateData), {
    expirationTtl: STATE_TTL,
  });

  // Build callback URL
  const callbackUrl = new URL('/api/auth/callback', url.origin).toString();
  const config = getOAuthConfig(env, callbackUrl);

  // Redirect to GitHub
  const authUrl = getAuthorizationUrl(config, state);
  return Response.redirect(authUrl, 302);
}

/**
 * Callback handler - Exchanges code for token and creates session
 */
export async function handleCallback(request: Request, env: CloudflareEnv): Promise<Response> {
  const url = new URL(request.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const error = url.searchParams.get('error');

  // Handle OAuth error
  if (error) {
    const errorDescription = url.searchParams.get('error_description') || error;
    return new Response(
      `
      <!DOCTYPE html>
      <html>
        <head><title>Login Error</title></head>
        <body>
          <h1>Login Error</h1>
          <p>${escapeHtml(errorDescription)}</p>
          <a href="/api/auth/login">Try again</a>
        </body>
      </html>
      `,
      {
        status: 400,
        headers: { 'Content-Type': 'text/html' },
      },
    );
  }

  // Validate required params
  if (!code || !state) {
    return new Response('Missing code or state parameter', { status: 400 });
  }

  // Verify state (CSRF protection)
  const stateKey = `${STATE_KEY_PREFIX}${state}`;
  const stateDataRaw = await env.KV.get(stateKey);
  if (!stateDataRaw) {
    return new Response('Invalid or expired state', { status: 400 });
  }

  // Delete used state
  await env.KV.delete(stateKey);

  const stateData = JSON.parse(stateDataRaw) as { redirectTo: string; createdAt: number };

  try {
    // Build callback URL for OAuth config
    const callbackUrl = new URL('/api/auth/callback', url.origin).toString();
    const config = getOAuthConfig(env, callbackUrl);

    // Complete OAuth flow
    const { user, accessToken, email } = await completeOAuthFlow(code, config);

    // Create session
    const sessionId = generateSessionId();
    const sessionData = await createSessionData(
      user,
      email,
      accessToken,
      env.ENCRYPTION_KEY,
      DEFAULT_SESSION_TTL,
    );

    // Store session in KV
    const storage = createKVStorage(env.KV);
    await storeSession(storage, sessionId, sessionData, DEFAULT_SESSION_TTL);

    // Create session cookie
    const isSecure = url.protocol === 'https:';
    const cookie = createSessionCookie(sessionId, DEFAULT_SESSION_TTL, { secure: isSecure });

    // Redirect to original destination
    return new Response(null, {
      status: 302,
      headers: {
        Location: stateData.redirectTo,
        'Set-Cookie': cookie,
      },
    });
  } catch (error) {
    console.error('[SaastroCMS] OAuth callback error:', error);
    const message = error instanceof Error ? error.message : 'Authentication failed';
    return new Response(
      `
      <!DOCTYPE html>
      <html>
        <head><title>Login Error</title></head>
        <body>
          <h1>Authentication Failed</h1>
          <p>${escapeHtml(message)}</p>
          <a href="/api/auth/login">Try again</a>
        </body>
      </html>
      `,
      {
        status: 500,
        headers: { 'Content-Type': 'text/html' },
      },
    );
  }
}

/**
 * Logout handler - Clears session
 */
export async function handleLogout(request: Request, env: CloudflareEnv): Promise<Response> {
  const url = new URL(request.url);
  const redirectTo = url.searchParams.get('redirect') || '/';

  // Get session ID from cookie
  const cookieHeader = request.headers.get('Cookie');
  const sessionId = parseSessionCookie(cookieHeader);

  // Delete session from KV if exists
  if (sessionId) {
    const storage = createKVStorage(env.KV);
    await deleteSession(storage, sessionId);
  }

  // Clear cookie
  const clearCookie = createClearSessionCookie();

  return new Response(null, {
    status: 302,
    headers: {
      Location: redirectTo,
      'Set-Cookie': clearCookie,
    },
  });
}

/**
 * Get current session info (for API)
 */
export async function handleSession(request: Request, env: CloudflareEnv): Promise<Response> {
  const cookieHeader = request.headers.get('Cookie');
  const sessionId = parseSessionCookie(cookieHeader);

  if (!sessionId) {
    return Response.json({ authenticated: false }, { status: 401 });
  }

  const storage = createKVStorage(env.KV);
  const session = await storage.get(`session:${sessionId}`);

  if (!session) {
    return Response.json({ authenticated: false }, { status: 401 });
  }

  // Return safe session data (no token)
  return Response.json({
    authenticated: true,
    user: {
      id: session.userId,
      githubId: session.githubId ?? null,
      username: session.githubUsername ?? null,
      email: session.email,
      name: session.name,
      avatarUrl: session.avatarUrl,
    },
  });
}

/**
 * Route handler for auth endpoints
 */
export async function handleAuthRequest(request: Request, env: CloudflareEnv): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;

  if (path === '/api/auth/login' && request.method === 'GET') {
    return handleLogin(request, env);
  }

  if (path === '/api/auth/callback' && request.method === 'GET') {
    return handleCallback(request, env);
  }

  if (path === '/api/auth/logout' && (request.method === 'GET' || request.method === 'POST')) {
    return handleLogout(request, env);
  }

  if (path === '/api/auth/session' && request.method === 'GET') {
    return handleSession(request, env);
  }

  return new Response('Not Found', { status: 404 });
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
