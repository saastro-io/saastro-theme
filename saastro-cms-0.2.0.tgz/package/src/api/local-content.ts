/**
 * Local Filesystem Content API Handler
 *
 * Used in dev mode (when _localContentRoot is set) to read/write content
 * directly from/to the local filesystem instead of GitHub API.
 *
 * Benefits:
 * - See all local files immediately (no need to push to GitHub first)
 * - Faster operations (no network round-trip)
 * - Works offline
 * - Normal git workflow: edit locally, then push when ready
 *
 * Node.js-only — dynamically imported only in dev mode.
 */

import { readdir, readFile, writeFile, unlink, mkdir, stat } from 'node:fs/promises';
import { join, dirname, resolve, basename, extname } from 'node:path';
import { createHash } from 'node:crypto';
import yaml from 'js-yaml';
import type { SaastroCMSConfig } from '../types.js';

// ── Utilities ────────────────────────────────────────────────

/** Compute Git-compatible blob SHA-1 so SHAs match between local and GitHub */
function gitSha(content: string): string {
  const buf = Buffer.from(content, 'utf-8');
  return createHash('sha1').update(`blob ${buf.length}\0`).update(buf).digest('hex');
}

function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function parseYamlContent(raw: string): { frontmatter: Record<string, unknown> } {
  return { frontmatter: (yaml.load(raw) as Record<string, unknown>) ?? {} };
}

function serializeYamlContent(frontmatter: Record<string, unknown>): string {
  return yaml.dump(frontmatter, { indent: 2, lineWidth: -1, noRefs: true });
}

function parseFrontmatter(raw: string): { frontmatter: Record<string, unknown>; body: string } {
  const match = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!match) return { frontmatter: {}, body: raw.trim() };
  const frontmatter = (yaml.load(match[1]!) as Record<string, unknown>) ?? {};
  return { frontmatter, body: (match[2] ?? '').trim() };
}

/** Strip null/undefined values recursively (for Zod schema compat) */
function stripNulls(obj: Record<string, unknown>): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v === null || v === undefined) continue;
    if (Array.isArray(v)) {
      result[k] = v.map((item) =>
        item && typeof item === 'object' && !Array.isArray(item)
          ? stripNulls(item as Record<string, unknown>)
          : item,
      );
    } else if (typeof v === 'object') {
      result[k] = stripNulls(v as Record<string, unknown>);
    } else {
      result[k] = v;
    }
  }
  return result;
}

// ── i18n locale subdirectory detection ───────────────────────

/**
 * Returns the available locale directories for a collection, or null if the
 * collection is not an i18n collection.
 *
 * Detection is config-driven: a collection must have `i18n: true` in its
 * config to be treated as multilingual. We never guess from the filesystem —
 * that approach was fragile and broke when stray flat files appeared.
 *
 * Only `multiple_folders` structure is currently supported (locale subdirs).
 */
async function detectLocaleDirs(
  contentRoot: string,
  collection: string,
  config: SaastroCMSConfig,
): Promise<string[] | null> {
  // Collection must explicitly opt in to i18n
  const colConfig = config.collections?.[collection] as Record<string, unknown> | undefined;
  if (!colConfig?.i18n) return null;

  const locales = config.i18n?.locales;
  if (!locales || locales.length === 0) return null;

  // Only multiple_folders is implemented (default)
  const structure = config.i18n?.structure ?? 'multiple_folders';
  if (structure !== 'multiple_folders') return null;

  // Return locales whose subdirectory actually exists on disk
  const dirPath = join(contentRoot, collection);
  const entries = await listLocalDir(dirPath);
  const dirNames = entries.filter((e) => e.type === 'dir').map((e) => e.name);
  const available = locales.filter((loc) => dirNames.includes(loc));
  return available.length > 0 ? available : locales; // fall back to all configured locales
}

/**
 * Resolve the locale to use for an entry operation.
 * Falls back to defaultLocale, or the first available locale.
 */
function resolveLocale(
  requested: string | null,
  availableLocales: string[],
  config: SaastroCMSConfig,
): string {
  if (requested && availableLocales.includes(requested)) return requested;
  const defaultLocale = config.i18n?.defaultLocale;
  if (defaultLocale && availableLocales.includes(defaultLocale)) return defaultLocale;
  return availableLocales[0]!;
}

/** Resolve file extension for a slug inside a specific locale subdirectory. */
async function resolveExtLocalI18n(
  contentRoot: string,
  collection: string,
  locale: string,
  slug: string,
): Promise<'yaml' | 'yml' | 'mdx' | 'md'> {
  for (const ext of ['yaml', 'yml', 'mdx'] as const) {
    const path = join(contentRoot, collection, locale, `${slug}.${ext}`);
    if (await fileExists(path)) return ext;
  }
  return 'md';
}

/** Detect format for a locale subdirectory. */
async function detectFormatLocaleDir(
  contentRoot: string,
  collection: string,
  locale: string,
): Promise<'yaml' | 'md'> {
  const dirPath = join(contentRoot, collection, locale);
  const entries = await listLocalDir(dirPath);
  const hasYaml = entries.some(
    (e) => e.type === 'file' && (e.name.endsWith('.yaml') || e.name.endsWith('.yml')),
  );
  return hasYaml ? 'yaml' : 'md';
}

/** Find which locales contain a given slug. */
async function findSlugLocales(
  contentRoot: string,
  collection: string,
  slug: string,
  locales: string[],
): Promise<string[]> {
  const found: string[] = [];
  for (const locale of locales) {
    for (const ext of ['yaml', 'yml', 'mdx', 'md']) {
      const path = join(contentRoot, collection, locale, `${slug}.${ext}`);
      if (await fileExists(path)) {
        found.push(locale);
        break;
      }
    }
  }
  return found;
}

// ── Low-level filesystem operations ──────────────────────────

async function fileExists(path: string): Promise<boolean> {
  try {
    await stat(path);
    return true;
  } catch {
    return false;
  }
}

async function readLocalFile(path: string): Promise<{ content: string; sha: string } | null> {
  try {
    const content = await readFile(path, 'utf-8');
    return { content, sha: gitSha(content) };
  } catch {
    return null;
  }
}

async function listLocalDir(
  dirPath: string,
): Promise<Array<{ name: string; type: 'file' | 'dir' }>> {
  try {
    const entries = await readdir(dirPath, { withFileTypes: true });
    return entries.map((e) => ({
      name: e.name,
      type: e.isDirectory() ? ('dir' as const) : ('file' as const),
    }));
  } catch {
    return [];
  }
}

// ── Format detection ─────────────────────────────────────────

async function detectFormatLocal(contentRoot: string, collection: string): Promise<'yaml' | 'md'> {
  const dirPath = join(contentRoot, collection);
  const entries = await listLocalDir(dirPath);
  const hasYaml = entries.some(
    (e) => e.type === 'file' && (e.name.endsWith('.yaml') || e.name.endsWith('.yml')),
  );
  return hasYaml ? 'yaml' : 'md';
}

async function resolveExtLocal(
  contentRoot: string,
  collection: string,
  slug: string,
): Promise<'yaml' | 'yml' | 'mdx' | 'md'> {
  for (const ext of ['yaml', 'yml', 'mdx'] as const) {
    const path = join(contentRoot, collection, `${slug}.${ext}`);
    if (await fileExists(path)) return ext;
  }
  return 'md';
}

// ── YAML entry operations ────────────────────────────────────

async function listYamlEntriesLocal(contentRoot: string, collection: string): Promise<Response> {
  const dirPath = join(contentRoot, collection);
  const files = await listLocalDir(dirPath);
  const entries: Array<{
    slug: string;
    collection: string;
    path: string;
    sha: string;
    frontmatter: Record<string, unknown>;
  }> = [];

  for (const file of files) {
    if (file.type !== 'file' || !(file.name.endsWith('.yaml') || file.name.endsWith('.yml'))) {
      continue;
    }

    const slug = file.name.replace(/\.ya?ml$/, '');
    const filePath = join(dirPath, file.name);
    const result = await readLocalFile(filePath);
    if (!result) continue;

    const { frontmatter } = parseYamlContent(result.content);
    entries.push({
      slug,
      collection,
      path: `${collection}/${file.name}`,
      sha: result.sha,
      frontmatter,
    });
  }

  return jsonResponse({ entries });
}

async function getYamlEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
): Promise<Response | null> {
  for (const ext of ['yaml', 'yml']) {
    const filePath = join(contentRoot, collection, `${slug}.${ext}`);
    const result = await readLocalFile(filePath);
    if (!result) continue;

    const { frontmatter } = parseYamlContent(result.content);
    return jsonResponse({
      entry: {
        slug,
        collection,
        path: `${collection}/${slug}.${ext}`,
        sha: result.sha,
        frontmatter,
        body: '',
      },
    });
  }
  return null;
}

async function createYamlEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
  frontmatter: Record<string, unknown>,
): Promise<Response> {
  const filePath = join(contentRoot, collection, `${slug}.yaml`);
  if (await fileExists(filePath)) {
    return jsonResponse(
      { error: 'conflict', message: `Entry "${slug}" already exists in ${collection}` },
      409,
    );
  }

  await mkdir(dirname(filePath), { recursive: true });
  const content = serializeYamlContent(stripNulls(frontmatter));
  await writeFile(filePath, content, 'utf-8');
  const sha = gitSha(content);

  return jsonResponse(
    {
      entry: {
        slug,
        collection,
        path: `${collection}/${slug}.yaml`,
        sha,
        frontmatter,
        body: '',
      },
    },
    201,
  );
}

async function updateYamlEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
  _sha: string,
  frontmatter: Record<string, unknown>,
): Promise<Response> {
  const ext = await resolveExtLocal(contentRoot, collection, slug);
  const filePath = join(contentRoot, collection, `${slug}.${ext}`);

  const content = serializeYamlContent(stripNulls(frontmatter));
  await mkdir(dirname(filePath), { recursive: true });
  await writeFile(filePath, content, 'utf-8');
  const sha = gitSha(content);

  return jsonResponse({
    entry: {
      slug,
      collection,
      path: `${collection}/${slug}.${ext}`,
      sha,
      frontmatter,
      body: '',
    },
  });
}

// ── MD/MDX entry operations ──────────────────────────────────

async function listMdEntriesLocal(contentRoot: string, collection: string): Promise<Response> {
  const dirPath = join(contentRoot, collection);
  const files = await listLocalDir(dirPath);
  const entries: Array<{
    slug: string;
    collection: string;
    path: string;
    sha: string;
    frontmatter: Record<string, unknown>;
    body: string;
  }> = [];

  for (const file of files) {
    if (file.type !== 'file') continue;
    if (!file.name.endsWith('.md') && !file.name.endsWith('.mdx')) {
      continue;
    }

    const slug = file.name.replace(/\.mdx?$/, '');
    const filePath = join(dirPath, file.name);
    const result = await readLocalFile(filePath);
    if (!result) continue;

    const { frontmatter, body } = parseFrontmatter(result.content);
    entries.push({
      slug,
      collection,
      path: `${collection}/${file.name}`,
      sha: result.sha,
      frontmatter,
      body,
    });
  }

  return jsonResponse({ entries });
}

async function getMdEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
): Promise<Response | null> {
  for (const ext of ['mdx', 'md']) {
    const filePath = join(contentRoot, collection, `${slug}.${ext}`);
    const result = await readLocalFile(filePath);
    if (!result) continue;

    const { frontmatter, body } = parseFrontmatter(result.content);
    return jsonResponse({
      entry: {
        slug,
        collection,
        path: `${collection}/${slug}.${ext}`,
        sha: result.sha,
        frontmatter,
        body,
      },
    });
  }
  return null;
}

async function createMdEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
  frontmatter: Record<string, unknown>,
  body: string,
  ext: 'md' | 'mdx' = 'md',
): Promise<Response> {
  const filePath = join(contentRoot, collection, `${slug}.${ext}`);
  if (await fileExists(filePath)) {
    return jsonResponse(
      { error: 'conflict', message: `Entry "${slug}" already exists in ${collection}` },
      409,
    );
  }

  await mkdir(dirname(filePath), { recursive: true });
  const fmStr = yaml
    .dump(stripNulls(frontmatter), { indent: 2, lineWidth: -1, noRefs: true })
    .trim();
  const content = `---\n${fmStr}\n---\n\n${body || ''}`;
  await writeFile(filePath, content, 'utf-8');
  const sha = gitSha(content);

  return jsonResponse(
    {
      entry: {
        slug,
        collection,
        path: `${collection}/${slug}.${ext}`,
        sha,
        frontmatter,
        body: body || '',
      },
    },
    201,
  );
}

async function updateMdEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
  _sha: string,
  frontmatter: Record<string, unknown>,
  body: string,
): Promise<Response> {
  const ext = await resolveExtLocal(contentRoot, collection, slug);
  const filePath = join(contentRoot, collection, `${slug}.${ext}`);

  let content: string;
  if (ext === 'yaml' || ext === 'yml') {
    content = serializeYamlContent(stripNulls(frontmatter));
  } else {
    const fmStr = yaml
      .dump(stripNulls(frontmatter), { indent: 2, lineWidth: -1, noRefs: true })
      .trim();
    content = `---\n${fmStr}\n---\n\n${body || ''}`;
  }

  await mkdir(dirname(filePath), { recursive: true });
  await writeFile(filePath, content, 'utf-8');
  const sha = gitSha(content);

  return jsonResponse({
    entry: {
      slug,
      collection,
      path: `${collection}/${slug}.${ext}`,
      sha,
      frontmatter,
      body: body || '',
    },
  });
}

// ── Delete ───────────────────────────────────────────────────

async function deleteEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
): Promise<Response> {
  const ext = await resolveExtLocal(contentRoot, collection, slug);
  const filePath = join(contentRoot, collection, `${slug}.${ext}`);

  try {
    await unlink(filePath);
    return jsonResponse({ deleted: true });
  } catch (error) {
    return jsonResponse(
      {
        error: 'internal_error',
        message: error instanceof Error ? error.message : 'Failed to delete',
      },
      500,
    );
  }
}

// ── i18n: Locale-subdirectory entry operations ───────────────

/**
 * List entries for a locale-subdirectory collection.
 * When `requestedLocale` is provided, returns entries from that locale's directory.
 * Otherwise falls back to the default locale (or first available).
 * Always includes `availableLocales` on each entry.
 */
async function listI18nEntriesLocal(
  contentRoot: string,
  collection: string,
  availableLocales: string[],
  config: SaastroCMSConfig,
  requestedLocale: string | null = null,
): Promise<Response> {
  const defaultLocale = resolveLocale(requestedLocale, availableLocales, config);

  // Aggregate slugs across all locales; track per-slug locales and file format
  const slugMap = new Map<
    string,
    {
      locales: Set<string>;
      format: Map<string, { ext: 'yaml' | 'yml' | 'mdx' | 'md' }>;
    }
  >();

  for (const locale of availableLocales) {
    const dirPath = join(contentRoot, collection, locale);
    const files = await listLocalDir(dirPath);
    for (const file of files) {
      if (file.type !== 'file') continue;
      const match = file.name.match(/^(.+)\.(yaml|yml|mdx|md)$/);
      if (!match) continue;
      const slug = match[1]!;
      const ext = match[2] as 'yaml' | 'yml' | 'mdx' | 'md';

      let record = slugMap.get(slug);
      if (!record) {
        record = { locales: new Set(), format: new Map() };
        slugMap.set(slug, record);
      }
      record.locales.add(locale);
      record.format.set(locale, { ext });
    }
  }

  const entries: Array<{
    slug: string;
    collection: string;
    path: string;
    sha: string;
    frontmatter: Record<string, unknown>;
    body: string;
    locale: string;
    availableLocales: string[];
  }> = [];

  // Emit one entry per slug, reading from the requested locale (or defaultLocale as fallback)
  const sortedSlugs = Array.from(slugMap.keys()).sort();
  for (const slug of sortedSlugs) {
    const record = slugMap.get(slug)!;
    const primaryLocale = record.locales.has(defaultLocale)
      ? defaultLocale
      : Array.from(record.locales).sort()[0]!;
    const fmt = record.format.get(primaryLocale);
    if (!fmt) continue;
    const filePath = join(contentRoot, collection, primaryLocale, `${slug}.${fmt.ext}`);
    const result = await readLocalFile(filePath);
    if (!result) continue;

    const isYaml = fmt.ext === 'yaml' || fmt.ext === 'yml';
    const { frontmatter, body } = isYaml
      ? { ...parseYamlContent(result.content), body: '' }
      : parseFrontmatter(result.content);

    entries.push({
      slug,
      collection,
      path: `${collection}/${primaryLocale}/${slug}.${fmt.ext}`,
      sha: result.sha,
      frontmatter,
      body,
      locale: primaryLocale,
      availableLocales: Array.from(record.locales).sort(),
    });
  }

  return jsonResponse({ entries });
}

/**
 * Get a single entry for a locale-subdirectory collection.
 * Respects `?locale=xx` query param (falls back to default locale).
 */
async function getI18nEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
  requestedLocale: string | null,
  availableLocales: string[],
  config: SaastroCMSConfig,
): Promise<Response> {
  const perSlugLocales = await findSlugLocales(contentRoot, collection, slug, availableLocales);
  if (perSlugLocales.length === 0) {
    return jsonResponse({ error: 'not_found', message: `Entry "${slug}" not found` }, 404);
  }

  const locale = resolveLocale(requestedLocale, perSlugLocales, config);
  const ext = await resolveExtLocalI18n(contentRoot, collection, locale, slug);
  const filePath = join(contentRoot, collection, locale, `${slug}.${ext}`);
  const result = await readLocalFile(filePath);
  if (!result) {
    return jsonResponse(
      { error: 'not_found', message: `Entry "${slug}" not found in locale "${locale}"` },
      404,
    );
  }

  const isYaml = ext === 'yaml' || ext === 'yml';
  const { frontmatter, body } = isYaml
    ? { ...parseYamlContent(result.content), body: '' }
    : parseFrontmatter(result.content);

  return jsonResponse({
    entry: {
      slug,
      collection,
      path: `${collection}/${locale}/${slug}.${ext}`,
      sha: result.sha,
      frontmatter,
      body,
      locale,
      availableLocales: perSlugLocales.sort(),
    },
  });
}

/**
 * Create a new entry in a locale-subdirectory collection.
 * The entry goes in `?locale=xx` if provided, otherwise the default locale.
 */
async function createI18nEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
  frontmatter: Record<string, unknown>,
  body: string,
  requestedLocale: string | null,
  availableLocales: string[],
  config: SaastroCMSConfig,
  explicitFormat?: 'yaml' | 'md',
): Promise<Response> {
  const locale = resolveLocale(requestedLocale, availableLocales, config);
  const format =
    explicitFormat ?? (await detectFormatLocaleDir(contentRoot, collection, locale));

  if (format === 'yaml') {
    const filePath = join(contentRoot, collection, locale, `${slug}.yaml`);
    if (await fileExists(filePath)) {
      return jsonResponse(
        {
          error: 'conflict',
          message: `Entry "${slug}" already exists in ${collection}/${locale}`,
        },
        409,
      );
    }
    await mkdir(dirname(filePath), { recursive: true });
    const content = serializeYamlContent(stripNulls(frontmatter));
    await writeFile(filePath, content, 'utf-8');
    const sha = gitSha(content);
    const perSlugLocales = await findSlugLocales(
      contentRoot,
      collection,
      slug,
      availableLocales,
    );
    return jsonResponse(
      {
        entry: {
          slug,
          collection,
          path: `${collection}/${locale}/${slug}.yaml`,
          sha,
          frontmatter,
          body: '',
          locale,
          availableLocales: perSlugLocales.sort(),
        },
      },
      201,
    );
  }

  // Markdown
  const filePath = join(contentRoot, collection, locale, `${slug}.md`);
  if (await fileExists(filePath)) {
    return jsonResponse(
      {
        error: 'conflict',
        message: `Entry "${slug}" already exists in ${collection}/${locale}`,
      },
      409,
    );
  }
  await mkdir(dirname(filePath), { recursive: true });
  const fmStr = yaml
    .dump(stripNulls(frontmatter), { indent: 2, lineWidth: -1, noRefs: true })
    .trim();
  const content = `---\n${fmStr}\n---\n\n${body || ''}`;
  await writeFile(filePath, content, 'utf-8');
  const sha = gitSha(content);
  const perSlugLocales = await findSlugLocales(contentRoot, collection, slug, availableLocales);
  return jsonResponse(
    {
      entry: {
        slug,
        collection,
        path: `${collection}/${locale}/${slug}.md`,
        sha,
        frontmatter,
        body: body || '',
        locale,
        availableLocales: perSlugLocales.sort(),
      },
    },
    201,
  );
}

/**
 * Update an entry in a locale-subdirectory collection.
 * Targets the file in `?locale=xx` (falls back to default locale).
 */
async function updateI18nEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
  frontmatter: Record<string, unknown>,
  body: string,
  requestedLocale: string | null,
  availableLocales: string[],
  config: SaastroCMSConfig,
): Promise<Response> {
  const perSlugLocales = await findSlugLocales(contentRoot, collection, slug, availableLocales);
  // When updating, if the file doesn't exist yet in the requested locale we
  // still allow the write (creates a new translation).
  const localeSet = perSlugLocales.length > 0 ? perSlugLocales : availableLocales;
  const locale = resolveLocale(requestedLocale, localeSet, config);
  const ext = await resolveExtLocalI18n(contentRoot, collection, locale, slug);
  const filePath = join(contentRoot, collection, locale, `${slug}.${ext}`);

  let content: string;
  const isYaml = ext === 'yaml' || ext === 'yml';
  if (isYaml) {
    content = serializeYamlContent(stripNulls(frontmatter));
  } else {
    const fmStr = yaml
      .dump(stripNulls(frontmatter), { indent: 2, lineWidth: -1, noRefs: true })
      .trim();
    content = `---\n${fmStr}\n---\n\n${body || ''}`;
  }

  await mkdir(dirname(filePath), { recursive: true });
  await writeFile(filePath, content, 'utf-8');
  const sha = gitSha(content);

  const refreshedLocales = await findSlugLocales(
    contentRoot,
    collection,
    slug,
    availableLocales,
  );

  return jsonResponse({
    entry: {
      slug,
      collection,
      path: `${collection}/${locale}/${slug}.${ext}`,
      sha,
      frontmatter,
      body: isYaml ? '' : body || '',
      locale,
      availableLocales: refreshedLocales.sort(),
    },
  });
}

/**
 * Delete an entry from a locale-subdirectory collection.
 * If `?locale=xx` is provided, only that locale's file is deleted.
 * Otherwise, files in all locales are deleted.
 */
async function deleteI18nEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
  requestedLocale: string | null,
  availableLocales: string[],
): Promise<Response> {
  const perSlugLocales = await findSlugLocales(contentRoot, collection, slug, availableLocales);
  if (perSlugLocales.length === 0) {
    return jsonResponse({ error: 'not_found', message: `Entry "${slug}" not found` }, 404);
  }

  const targets = requestedLocale
    ? perSlugLocales.filter((l) => l === requestedLocale)
    : perSlugLocales;

  if (targets.length === 0) {
    return jsonResponse(
      {
        error: 'not_found',
        message: `Entry "${slug}" not found in locale "${requestedLocale}"`,
      },
      404,
    );
  }

  const deleted: string[] = [];
  for (const locale of targets) {
    const ext = await resolveExtLocalI18n(contentRoot, collection, locale, slug);
    const filePath = join(contentRoot, collection, locale, `${slug}.${ext}`);
    try {
      await unlink(filePath);
      deleted.push(locale);
    } catch {
      // swallow; continue with other locales
    }
  }

  return jsonResponse({ deleted: true, locales: deleted });
}

// ── Rename ───────────────────────────────────────────────────

async function renameEntryLocal(
  contentRoot: string,
  collection: string,
  slug: string,
  newSlug: string,
  frontmatter: Record<string, unknown>,
  body: string,
): Promise<Response> {
  // Check new slug doesn't exist
  for (const checkExt of ['yaml', 'yml', 'mdx', 'md']) {
    const checkPath = join(contentRoot, collection, `${newSlug}.${checkExt}`);
    if (await fileExists(checkPath)) {
      return jsonResponse(
        { error: 'conflict', message: `Slug "${newSlug}" already exists in ${collection}` },
        409,
      );
    }
  }

  const ext = await resolveExtLocal(contentRoot, collection, slug);
  const oldPath = join(contentRoot, collection, `${slug}.${ext}`);
  const newPath = join(contentRoot, collection, `${newSlug}.${ext}`);

  // Write new file
  let content: string;
  if (ext === 'yaml' || ext === 'yml') {
    content = serializeYamlContent(stripNulls(frontmatter));
  } else {
    const fmStr = yaml
      .dump(stripNulls(frontmatter), { indent: 2, lineWidth: -1, noRefs: true })
      .trim();
    content = `---\n${fmStr}\n---\n\n${body || ''}`;
  }

  await mkdir(dirname(newPath), { recursive: true });
  await writeFile(newPath, content, 'utf-8');
  const sha = gitSha(content);

  // Delete old file
  try {
    await unlink(oldPath);
  } catch {
    // Old file might not exist
  }

  return jsonResponse({
    entry: {
      slug: newSlug,
      collection,
      path: `${collection}/${newSlug}.${ext}`,
      sha,
      frontmatter,
      body: body || '',
    },
    renamed: true,
  });
}

// ── Slug check ───────────────────────────────────────────────

async function checkSlugLocal(
  contentRoot: string,
  collection: string,
  slug: string,
  exclude: string | null,
): Promise<Response> {
  if (exclude && slug === exclude) {
    return jsonResponse({ available: true });
  }

  for (const ext of ['yaml', 'yml', 'mdx', 'md']) {
    const path = join(contentRoot, collection, `${slug}.${ext}`);
    if (await fileExists(path)) {
      return jsonResponse({ available: false });
    }
  }

  return jsonResponse({ available: true });
}

// ── Layout ───────────────────────────────────────────────────

async function getLayoutLocal(contentRoot: string, collection: string): Promise<Response> {
  const layoutPath = join(contentRoot, '.saastrocms', 'layouts', `${collection}.json`);
  const result = await readLocalFile(layoutPath);

  if (!result) {
    return jsonResponse({ layout: null });
  }

  try {
    const layout = JSON.parse(result.content);
    return jsonResponse({ layout, sha: result.sha });
  } catch {
    return jsonResponse({ layout: null });
  }
}

async function saveLayoutLocal(
  contentRoot: string,
  collection: string,
  layout: unknown,
): Promise<Response> {
  const layoutPath = join(contentRoot, '.saastrocms', 'layouts', `${collection}.json`);
  await mkdir(dirname(layoutPath), { recursive: true });
  const content = JSON.stringify(layout, null, 2);
  await writeFile(layoutPath, content, 'utf-8');
  const sha = gitSha(content);

  return jsonResponse({ saved: true, sha });
}

// ── Revisions (local git log) ────────────────────────────────

import { exec } from 'node:child_process';
import { promisify } from 'node:util';

const execAsync = promisify(exec);

/**
 * Get revision history for a file using local git log.
 * Falls back to empty array if git is not available or file has no history.
 */
async function getRevisionsLocal(
  contentRoot: string,
  collection: string,
  slug: string,
): Promise<Response> {
  const ext = await resolveExtLocal(contentRoot, collection, slug);
  const filePath = join(contentRoot, collection, `${slug}.${ext}`);

  try {
    const { stdout } = await execAsync(
      `git log --format="%H%n%an%n%aI%n%s" -n 50 -- "${filePath}"`,
      { cwd: contentRoot },
    );

    if (!stdout.trim()) {
      return jsonResponse({ revisions: [] });
    }

    const lines = stdout.trim().split('\n');
    const revisions: Array<{
      sha: string;
      author: string;
      date: string;
      message: string;
    }> = [];

    // Each commit = 4 lines (sha, author, date, message)
    for (let i = 0; i + 3 < lines.length; i += 4) {
      revisions.push({
        sha: lines[i]!,
        author: lines[i + 1]!,
        date: lines[i + 2]!,
        message: lines[i + 3]!,
      });
    }

    return jsonResponse({ revisions });
  } catch {
    // Git not available or not a git repo — return empty
    return jsonResponse({ revisions: [] });
  }
}

/**
 * Get the content of a file at a specific revision using git show.
 */
async function getRevisionContentLocal(
  contentRoot: string,
  collection: string,
  slug: string,
  sha: string,
): Promise<Response> {
  // Validate SHA format (hex, 7-40 chars)
  if (!/^[0-9a-f]{7,40}$/.test(sha)) {
    return jsonResponse({ error: 'validation_error', message: 'Invalid revision SHA' }, 400);
  }

  const ext = await resolveExtLocal(contentRoot, collection, slug);
  const relPath = `${collection}/${slug}.${ext}`;

  try {
    const { stdout } = await execAsync(`git show ${sha}:"${relPath}"`, {
      cwd: contentRoot,
    });

    const isYaml = ext === 'yaml' || ext === 'yml';
    if (isYaml) {
      const { frontmatter } = parseYamlContent(stdout);
      return jsonResponse({
        entry: { slug, collection, sha, frontmatter, body: '' },
      });
    }

    const { frontmatter, body } = parseFrontmatter(stdout);
    return jsonResponse({
      entry: { slug, collection, sha, frontmatter, body },
    });
  } catch {
    return jsonResponse(
      { error: 'not_found', message: `Revision ${sha} not found for ${relPath}` },
      404,
    );
  }
}

// ── Media (local filesystem) ─────────────────────────────────

/** Resolve the local media directory from config + contentRoot */
function resolveMediaDir(contentRoot: string, config: SaastroCMSConfig): string {
  // contentRoot = {projectRoot}/{contentPath} (e.g. /project/src/content)
  // mediaPath = config.media?.pathPrefix (e.g. "public/images")
  // We resolve relative to the project root (parent of contentPath)
  const contentPath = config.github.contentPath ?? 'src/content';
  const projectRoot = resolve(contentRoot, ...Array(contentPath.split('/').length).fill('..'));
  const mediaPath = config.media?.pathPrefix ?? 'public/images';
  return join(projectRoot, mediaPath);
}

/** Get file size in bytes */
async function getFileSize(path: string): Promise<number> {
  try {
    const s = await stat(path);
    return s.size;
  } catch {
    return 0;
  }
}

/** Get MIME type from extension */
function getMimeTypeLocal(ext: string): string {
  const types: Record<string, string> = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.svg': 'image/svg+xml',
    '.pdf': 'application/pdf',
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
  };
  return types[ext.toLowerCase()] || 'application/octet-stream';
}

/** Check if file type is allowed */
function isAllowedTypeLocal(mimeType: string, config: SaastroCMSConfig): boolean {
  const allowed = config.media?.allowedTypes ?? [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml',
    'application/pdf',
    'video/mp4',
    'video/webm',
  ];
  return allowed.includes(mimeType);
}

/** Compute public URL: strip "public" prefix so /public/images/x.png → /images/x.png */
function toPublicUrlLocal(mediaPath: string, filename: string, subdir: string): string {
  const fullPath = subdir ? `${mediaPath}/${subdir}/${filename}` : `${mediaPath}/${filename}`;
  if (fullPath.startsWith('public/')) {
    return '/' + fullPath.slice('public/'.length);
  }
  return '/' + fullPath;
}

async function listMediaLocal(
  request: Request,
  contentRoot: string,
  config: SaastroCMSConfig,
): Promise<Response> {
  const mediaDir = resolveMediaDir(contentRoot, config);
  const mediaPath = config.media?.pathPrefix ?? 'public/images';
  const url = new URL(request.url);
  const subdir = url.searchParams.get('subdir') || '';
  const browseDir = subdir ? join(mediaDir, subdir) : mediaDir;

  const entries = await listLocalDir(browseDir);

  const items: Array<{
    name: string;
    path: string;
    url: string;
    publicUrl: string;
    sha: string;
    size: number;
    type: string;
    isDirectory?: boolean;
  }> = [];

  // Directories first
  for (const entry of entries) {
    if (entry.type === 'dir') {
      const repoPath = subdir
        ? `${mediaPath}/${subdir}/${entry.name}`
        : `${mediaPath}/${entry.name}`;
      items.push({
        name: entry.name,
        path: repoPath,
        url: '',
        publicUrl: toPublicUrlLocal(mediaPath, entry.name, subdir),
        sha: '',
        size: 0,
        type: 'directory',
        isDirectory: true,
      });
    }
  }

  // Then files (filtered by allowed types)
  for (const entry of entries) {
    if (entry.type === 'file') {
      const ext = extname(entry.name);
      const mimeType = getMimeTypeLocal(ext);
      if (!isAllowedTypeLocal(mimeType, config)) continue;

      const filePath = join(browseDir, entry.name);
      const size = await getFileSize(filePath);
      const repoPath = subdir
        ? `${mediaPath}/${subdir}/${entry.name}`
        : `${mediaPath}/${entry.name}`;
      const publicUrl = toPublicUrlLocal(mediaPath, entry.name, subdir);

      // Use file content hash as SHA
      const fileResult = await readLocalFile(filePath);
      const sha = fileResult?.sha ?? '';

      items.push({
        name: entry.name,
        path: repoPath,
        url: publicUrl,
        publicUrl,
        sha,
        size,
        type: mimeType,
      });
    }
  }

  return jsonResponse({ items, subdir });
}

async function uploadMediaLocal(
  request: Request,
  contentRoot: string,
  config: SaastroCMSConfig,
): Promise<Response> {
  const mediaDir = resolveMediaDir(contentRoot, config);
  const mediaPath = config.media?.pathPrefix ?? 'public/images';

  const formData = await request.formData();
  const file = formData.get('file') as File | null;

  if (!file) {
    return jsonResponse({ error: 'validation_error', message: 'No file provided' }, 400);
  }

  // Check file size
  const maxSize = config.media?.maxSize ?? 5 * 1024 * 1024;
  if (file.size > maxSize) {
    return jsonResponse(
      {
        error: 'validation_error',
        message: `File too large. Max size: ${maxSize / 1024 / 1024}MB`,
      },
      400,
    );
  }

  // Check file type
  const ext = extname(file.name);
  const mimeType = getMimeTypeLocal(ext);
  if (!isAllowedTypeLocal(mimeType, config)) {
    return jsonResponse({ error: 'validation_error', message: 'File type not allowed' }, 400);
  }

  // Generate unique filename
  const baseName = basename(file.name, ext).replace(/[^a-z0-9-_]/gi, '-');
  const timestamp = Date.now();
  const filename = `${baseName}-${timestamp}${ext}`;

  const subdir = formData.get('subdir') as string | null;
  const destDir = subdir ? join(mediaDir, subdir) : mediaDir;
  const destPath = join(destDir, filename);

  await mkdir(destDir, { recursive: true });

  // Write file
  const arrayBuffer = await file.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  await writeFile(destPath, buffer);

  const sha = createHash('sha1').update(`blob ${buffer.length}\0`).update(buffer).digest('hex');
  const repoPath = subdir ? `${mediaPath}/${subdir}/${filename}` : `${mediaPath}/${filename}`;
  const publicUrl = toPublicUrlLocal(mediaPath, filename, subdir || '');

  return jsonResponse(
    {
      item: {
        name: filename,
        path: repoPath,
        url: publicUrl,
        publicUrl,
        sha,
        size: file.size,
        type: mimeType,
      },
    },
    201,
  );
}

async function deleteMediaLocal(
  _request: Request,
  filename: string,
  contentRoot: string,
  config: SaastroCMSConfig,
): Promise<Response> {
  const mediaDir = resolveMediaDir(contentRoot, config);

  // filename may contain subdir path segments (e.g. "brand/logo.png")
  const filePath = join(mediaDir, filename);

  try {
    await unlink(filePath);
    return jsonResponse({ deleted: true });
  } catch (error) {
    return jsonResponse(
      {
        error: 'not_found',
        message: error instanceof Error ? error.message : 'File not found',
      },
      404,
    );
  }
}

/**
 * Handle media requests in local dev mode.
 * Matches: /api/cms/media and /api/cms/media/:filename
 */
async function createFolderLocal(
  request: Request,
  contentRoot: string,
  config: SaastroCMSConfig,
): Promise<Response> {
  try {
    const body = (await request.json()) as { path?: string };
    const folderPath = body.path?.trim();

    if (!folderPath) {
      return jsonResponse({ error: 'validation_error', message: 'Folder path is required' }, 400);
    }

    const mediaDir = resolveMediaDir(contentRoot, config);
    const destDir = join(mediaDir, folderPath);

    await mkdir(destDir, { recursive: true });

    return jsonResponse({ created: true, path: folderPath }, 201);
  } catch (error) {
    return jsonResponse(
      {
        error: 'internal_error',
        message: error instanceof Error ? error.message : 'Failed to create folder',
      },
      500,
    );
  }
}

export async function handleMediaRequestLocal(
  request: Request,
  contentRoot: string,
  config: SaastroCMSConfig,
): Promise<Response | null> {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  // Match /api/cms/media/folder
  if (path === '/api/cms/media/folder' && method === 'POST') {
    return createFolderLocal(request, contentRoot, config);
  }

  const match = path.match(/^\/api\/cms\/media(?:\/(.+))?$/);
  if (!match) return null;

  const filename = match[1] as string | undefined;

  if (!filename) {
    if (method === 'GET') return listMediaLocal(request, contentRoot, config);
    if (method === 'POST') return uploadMediaLocal(request, contentRoot, config);
    return jsonResponse({ error: 'method_not_allowed' }, 405);
  }

  if (method === 'DELETE') {
    return deleteMediaLocal(request, filename, contentRoot, config);
  }

  return jsonResponse({ error: 'method_not_allowed' }, 405);
}

// ── Validation ───────────────────────────────────────────────

const SAFE_PATH_RE = /^[a-zA-Z0-9_][a-zA-Z0-9._\-]*$/;

function isValidPathSegment(segment: string): boolean {
  return SAFE_PATH_RE.test(segment) && !segment.includes('..');
}

// ── Main request router ──────────────────────────────────────

export async function handleContentRequestLocal(
  request: Request,
  contentRoot: string,
  config: SaastroCMSConfig,
): Promise<Response | null> {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  // Validate path segments to prevent path traversal
  const collectionsPrefix = '/api/cms/collections/';
  if (path.startsWith(collectionsPrefix)) {
    const rest = path.slice(collectionsPrefix.length);
    const segments = rest.split('/').filter(Boolean);
    for (const seg of segments) {
      if (['check-slug', 'layout', 'revisions'].includes(seg)) continue;
      if (!isValidPathSegment(seg)) {
        return jsonResponse(
          { error: 'validation_error', message: `Invalid path segment: "${seg}"` },
          400,
        );
      }
    }
  }

  // Check slug
  const checkSlugMatch = path.match(/^\/api\/cms\/collections\/([^/]+)\/check-slug$/);
  if (checkSlugMatch && checkSlugMatch[1]) {
    const collection = checkSlugMatch[1];
    if (method === 'GET') {
      const slug = url.searchParams.get('slug');
      const exclude = url.searchParams.get('exclude');
      if (!slug) {
        return jsonResponse(
          { error: 'validation_error', message: 'slug parameter is required' },
          400,
        );
      }
      return checkSlugLocal(contentRoot, collection, slug, exclude);
    }
    return jsonResponse({ error: 'method_not_allowed' }, 405);
  }

  // Layout
  const layoutMatch = path.match(/^\/api\/cms\/collections\/([^/]+)\/layout$/);
  if (layoutMatch && layoutMatch[1]) {
    const collection = layoutMatch[1];
    if (method === 'GET') return getLayoutLocal(contentRoot, collection);
    if (method === 'PUT') {
      const body = (await request.json()) as { layout: unknown };
      if (!body.layout) {
        return jsonResponse({ error: 'validation_error', message: 'layout is required' }, 400);
      }
      return saveLayoutLocal(contentRoot, collection, body.layout);
    }
    return jsonResponse({ error: 'method_not_allowed' }, 405);
  }

  // Revisions
  const revisionMatch = path.match(
    /^\/api\/cms\/collections\/([^/]+)\/([^/]+)\/revisions(?:\/([^/]+))?$/,
  );
  if (revisionMatch && revisionMatch[1] && revisionMatch[2]) {
    if (method !== 'GET') return jsonResponse({ error: 'method_not_allowed' }, 405);
    const collection = revisionMatch[1];
    const slug = revisionMatch[2];
    const sha = revisionMatch[3] as string | undefined;
    if (sha) return getRevisionContentLocal(contentRoot, collection, slug, sha);
    return getRevisionsLocal(contentRoot, collection, slug);
  }

  // Collection/Entry routes
  const match = path.match(/^\/api\/cms\/collections\/([^/]+)(?:\/([^/]+))?$/);
  if (!match || !match[1]) return null;

  const collection = match[1];
  const slug = match[2] as string | undefined;

  // Detect i18n locale-subdirectory layout once per request
  let localeDirs = await detectLocaleDirs(contentRoot, collection, config);
  const requestedLocale = url.searchParams.get('locale');

  // i18n singletons: _singletons is not in config.collections so detectLocaleDirs
  // returns null. Check the singleton config directly.
  if (collection === '_singletons' && slug && !localeDirs && config.i18n?.locales) {
    const singletonCfg = Object.values(config.singletons ?? {}).find(
      (s) => s.slug === slug && s.collection === '_singletons',
    );
    if (singletonCfg?.i18n) {
      localeDirs = config.i18n.locales;
    }
  }

  try {
    // Collection-level operations
    if (!slug) {
      if (method === 'GET') {
        if (localeDirs) {
          return listI18nEntriesLocal(contentRoot, collection, localeDirs, config, requestedLocale);
        }
        const format = await detectFormatLocal(contentRoot, collection);
        if (format === 'yaml') return listYamlEntriesLocal(contentRoot, collection);
        return listMdEntriesLocal(contentRoot, collection);
      }
      if (method === 'POST') {
        const body = (await request.json()) as {
          slug?: string;
          frontmatter?: Record<string, unknown>;
          body?: string;
          format?: 'yaml' | 'md';
        };
        if (!body.slug || !body.frontmatter) {
          return jsonResponse(
            { error: 'validation_error', message: 'slug and frontmatter are required' },
            400,
          );
        }
        if (localeDirs) {
          return createI18nEntryLocal(
            contentRoot,
            collection,
            body.slug,
            body.frontmatter,
            body.body || '',
            requestedLocale,
            localeDirs,
            config,
            body.format,
          );
        }
        const format = body.format ?? (await detectFormatLocal(contentRoot, collection));
        if (format === 'yaml') {
          return createYamlEntryLocal(contentRoot, collection, body.slug, body.frontmatter);
        }
        return createMdEntryLocal(
          contentRoot,
          collection,
          body.slug,
          body.frontmatter,
          body.body || '',
        );
      }
      return jsonResponse({ error: 'method_not_allowed' }, 405);
    }

    // Entry-level operations
    if (method === 'GET') {
      if (localeDirs) {
        return getI18nEntryLocal(
          contentRoot,
          collection,
          slug,
          requestedLocale,
          localeDirs,
          config,
        );
      }
      // Try YAML first
      const yamlResult = await getYamlEntryLocal(contentRoot, collection, slug);
      if (yamlResult) return yamlResult;
      // Fall back to MD/MDX
      const mdResult = await getMdEntryLocal(contentRoot, collection, slug);
      if (mdResult) return mdResult;
      return jsonResponse({ error: 'not_found', message: `Entry "${slug}" not found` }, 404);
    }

    if (method === 'PUT') {
      const body = (await request.json()) as {
        sha?: string;
        frontmatter?: Record<string, unknown>;
        body?: string;
        newSlug?: string;
      };

      if (!body.frontmatter) {
        return jsonResponse({ error: 'validation_error', message: 'frontmatter is required' }, 400);
      }

      if (localeDirs) {
        // Rename across locale subdirectories is intentionally unsupported for now —
        // it would require renaming the file in every locale and coordinating conflicts.
        if (body.newSlug && body.newSlug !== slug) {
          return jsonResponse(
            {
              error: 'not_implemented',
              message: 'Renaming entries in locale-subdirectory collections is not supported',
            },
            501,
          );
        }
        return updateI18nEntryLocal(
          contentRoot,
          collection,
          slug,
          body.frontmatter,
          body.body || '',
          requestedLocale,
          localeDirs,
          config,
        );
      }

      // Handle rename
      if (body.newSlug && body.newSlug !== slug) {
        return renameEntryLocal(
          contentRoot,
          collection,
          slug,
          body.newSlug,
          body.frontmatter,
          body.body || '',
        );
      }

      // Detect format
      const ext = await resolveExtLocal(contentRoot, collection, slug);
      const isYaml = ext === 'yaml' || ext === 'yml';

      if (isYaml) {
        return updateYamlEntryLocal(
          contentRoot,
          collection,
          slug,
          body.sha || '',
          body.frontmatter,
        );
      }

      return updateMdEntryLocal(
        contentRoot,
        collection,
        slug,
        body.sha || '',
        body.frontmatter,
        body.body || '',
      );
    }

    if (method === 'DELETE') {
      // In local mode we don't require SHA for delete. We read the body defensively
      // in case clients still send one.
      try {
        await request.json();
      } catch {
        // ignore empty body
      }
      if (localeDirs) {
        return deleteI18nEntryLocal(
          contentRoot,
          collection,
          slug,
          requestedLocale,
          localeDirs,
        );
      }
      return deleteEntryLocal(contentRoot, collection, slug);
    }

    return jsonResponse({ error: 'method_not_allowed' }, 405);
  } catch (error) {
    console.error('[SaastroCMS] Local content API error:', error);
    return jsonResponse(
      {
        error: 'internal_error',
        message: error instanceof Error ? error.message : 'Internal server error',
      },
      500,
    );
  }
}
