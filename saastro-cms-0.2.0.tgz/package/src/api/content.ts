/**
 * SaastroCMS Content API Handlers
 * REST API for content CRUD operations
 * Supports both Markdown (frontmatter + body) and YAML data collections
 */

import {
  ContentError,
  type RepositoryContext,
  createContentRequestSchema,
  createFetchTransport,
  createJsYamlParser,
  createLightContentService,
  updateContentRequestSchema,
} from '@saastro/core/light';
import yaml from 'js-yaml';

/** Create a lightweight content service using fetch + js-yaml */
function createContentService(token: string, context: RepositoryContext) {
  const transport = createFetchTransport(token);
  const parser = createJsYamlParser(yaml);
  return createLightContentService(transport, parser, context);
}
import type { SaastroCMSLocals } from '../middleware.js';
import type { SaastroCMSConfig } from '../types.js';
import { guardCMSRequest } from './auth-guard.js';

/** Decode base64 content from GitHub API to a proper UTF-8 string */
function decodeBase64(b64: string): string {
  const binary = atob(b64.replace(/\n/g, ''));
  const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
  return new TextDecoder('utf-8').decode(bytes);
}

/** Encode a UTF-8 string to base64 for GitHub API */
function encodeBase64(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary);
}

/**
 * Get repository context from config
 */
function getRepoContext(config: SaastroCMSConfig): RepositoryContext {
  return {
    owner: config.github.owner,
    repo: config.github.repo,
    branch: config.github.branch ?? 'main',
    contentPath: config.github.contentPath ?? 'src/content',
  };
}

// --- YAML data collection support ---

/**
 * Parse a raw YAML string into frontmatter object (no body for data collections)
 */
function parseYamlContent(raw: string): { frontmatter: Record<string, unknown> } {
  return { frontmatter: (yaml.load(raw) as Record<string, unknown>) ?? {} };
}

/**
 * Serialize frontmatter to YAML string
 */
function serializeYamlContent(frontmatter: Record<string, unknown>): string {
  return yaml.dump(frontmatter, { indent: 2, lineWidth: -1, noRefs: true });
}

/**
 * Parse frontmatter + body from a markdown/mdx string (--- delimited YAML header)
 */
function parseFrontmatter(raw: string): { frontmatter: Record<string, unknown>; body: string } {
  const match = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!match) return { frontmatter: {}, body: raw.trim() };
  const frontmatter = (yaml.load(match[1]!) as Record<string, unknown>) ?? {};
  return { frontmatter, body: (match[2] ?? '').trim() };
}

/**
 * Determine the file extension for a collection.
 * Checks for `.yaml` files first, then `.mdx`, then falls back to `.md`.
 */
async function resolveFileExtension(
  token: string,
  context: RepositoryContext,
  collection: string,
  slug: string,
): Promise<'yaml' | 'yml' | 'mdx' | 'md'> {
  for (const ext of ['yaml', 'yml', 'mdx'] as const) {
    const path = `${context.contentPath}/${collection}/${slug}.${ext}`;
    const resp = await fetch(
      `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(path)}?ref=${context.branch}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github.v3+json',
          'User-Agent': 'SaastroCMS/1.0',
        },
      },
    );
    if (resp.ok) return ext;
  }
  return 'md';
}

/**
 * Detect what extensions exist in a collection directory
 */
async function detectCollectionFormat(
  token: string,
  context: RepositoryContext,
  collection: string,
): Promise<'yaml' | 'md'> {
  const dirPath = `${context.contentPath}/${collection}`;
  const resp = await fetch(
    `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(dirPath)}?ref=${context.branch}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'SaastroCMS/1.0',
      },
    },
  );
  if (!resp.ok) return 'md';

  const files = (await resp.json()) as Array<{ name: string; type: string }>;
  const hasYaml = files.some(
    (f) => f.type === 'file' && (f.name.endsWith('.yaml') || f.name.endsWith('.yml')),
  );
  return hasYaml ? 'yaml' : 'md';
}

/**
 * YAML-aware: list entries from a YAML data collection
 */
async function listYamlEntries(
  token: string,
  context: RepositoryContext,
  collection: string,
): Promise<
  Array<{
    slug: string;
    collection: string;
    path: string;
    sha: string;
    frontmatter: Record<string, unknown>;
  }>
> {
  const dirPath = `${context.contentPath}/${collection}`;
  const resp = await fetch(
    `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(dirPath)}?ref=${context.branch}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'SaastroCMS/1.0',
      },
    },
  );

  if (!resp.ok) return [];

  const files = (await resp.json()) as Array<{
    name: string;
    path: string;
    sha: string;
    type: string;
  }>;

  const entries: Array<{
    slug: string;
    collection: string;
    path: string;
    sha: string;
    frontmatter: Record<string, unknown>;
  }> = [];

  for (const file of files) {
    if (file.type !== 'file' || !(file.name.endsWith('.yaml') || file.name.endsWith('.yml'))) {
      continue;
    }

    const slug = file.name.replace(/\.ya?ml$/, '');
    const fileResp = await fetch(
      `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(file.path)}?ref=${context.branch}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github.v3+json',
          'User-Agent': 'SaastroCMS/1.0',
        },
      },
    );

    if (!fileResp.ok) continue;
    const fileData = (await fileResp.json()) as { content: string; sha: string };
    const raw = decodeBase64(fileData.content);
    const { frontmatter } = parseYamlContent(raw);

    entries.push({
      slug,
      collection,
      path: file.path,
      sha: fileData.sha,
      frontmatter,
    });
  }

  return entries;
}

/**
 * YAML-aware: get a single YAML entry
 */
async function getYamlEntry(
  token: string,
  context: RepositoryContext,
  collection: string,
  slug: string,
): Promise<{
  entry: {
    slug: string;
    collection: string;
    path: string;
    sha: string;
    frontmatter: Record<string, unknown>;
    body: string;
  };
} | null> {
  for (const ext of ['yaml', 'yml']) {
    const path = `${context.contentPath}/${collection}/${slug}.${ext}`;
    const resp = await fetch(
      `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(path)}?ref=${context.branch}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github.v3+json',
          'User-Agent': 'SaastroCMS/1.0',
        },
      },
    );

    if (!resp.ok) continue;
    const data = (await resp.json()) as { content: string; sha: string; path: string };
    const raw = decodeBase64(data.content);
    const { frontmatter } = parseYamlContent(raw);

    return {
      entry: {
        slug,
        collection,
        path: data.path,
        sha: data.sha,
        frontmatter,
        body: '',
      },
    };
  }
  return null;
}

/**
 * YAML-aware: update a YAML entry
 */
async function updateYamlEntry(
  token: string,
  context: RepositoryContext,
  collection: string,
  slug: string,
  sha: string,
  frontmatter: Record<string, unknown>,
): Promise<{ sha: string; path: string }> {
  const ext = await resolveFileExtension(token, context, collection, slug);
  const path = `${context.contentPath}/${collection}/${slug}.${ext}`;
  const content = encodeBase64(serializeYamlContent(frontmatter));

  const resp = await fetch(
    `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(path)}`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
        'User-Agent': 'SaastroCMS/1.0',
      },
      body: JSON.stringify({
        message: `content: update ${collection}/${slug}`,
        content,
        sha,
        branch: context.branch,
      }),
    },
  );

  if (!resp.ok) {
    const err = (await resp.json()) as { message?: string };
    throw new Error(err.message || `GitHub API error: ${resp.status}`);
  }

  const result = (await resp.json()) as { content: { sha: string; path: string } };
  return { sha: result.content.sha, path: result.content.path };
}

/**
 * YAML-aware: create a new YAML entry
 */
async function createYamlEntry(
  token: string,
  context: RepositoryContext,
  collection: string,
  slug: string,
  frontmatter: Record<string, unknown>,
): Promise<{ sha: string; path: string }> {
  const path = `${context.contentPath}/${collection}/${slug}.yaml`;
  const content = encodeBase64(serializeYamlContent(frontmatter));

  const resp = await fetch(
    `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(path)}`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
        'User-Agent': 'SaastroCMS/1.0',
      },
      body: JSON.stringify({
        message: `content: create ${collection}/${slug}`,
        content,
        branch: context.branch,
      }),
    },
  );

  if (!resp.ok) {
    const err = (await resp.json()) as { message?: string };
    throw new Error(err.message || `GitHub API error: ${resp.status}`);
  }

  const result = (await resp.json()) as { content: { sha: string; path: string } };
  return { sha: result.content.sha, path: result.content.path };
}

/**
 * Delete a content entry file via GitHub Contents API.
 * Works for any format (YAML, MDX, MD) given the correct extension.
 */
async function deleteEntryFile(
  token: string,
  context: RepositoryContext,
  collection: string,
  slug: string,
  sha: string,
  ext: string,
): Promise<void> {
  const path = `${context.contentPath}/${collection}/${slug}.${ext}`;
  const resp = await fetch(
    `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(path)}`,
    {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
        'User-Agent': 'SaastroCMS/1.0',
      },
      body: JSON.stringify({
        message: `content: delete ${collection}/${slug}`,
        sha,
        branch: context.branch,
      }),
    },
  );

  if (!resp.ok) {
    const err = (await resp.json()) as { message?: string };
    throw new Error(err.message || `GitHub API error: ${resp.status}`);
  }
}

/**
 * Parse JSON body from request
 */
async function parseJsonBody(request: Request): Promise<unknown> {
  try {
    return await request.json();
  } catch {
    throw new ContentError('validation_error', 'Invalid JSON body', 400);
  }
}

/**
 * Create JSON response
 */
function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

/** Validate a collection name or slug — only safe path chars allowed */
const SAFE_PATH_RE = /^[a-zA-Z0-9][a-zA-Z0-9._-]*$/;

function isValidPathSegment(segment: string): boolean {
  return SAFE_PATH_RE.test(segment) && !segment.includes('..');
}

/**
 * Create error response
 */
function errorResponse(error: ContentError): Response {
  return jsonResponse(
    {
      error: error.code,
      message: error.message,
      details: error.details,
    },
    error.status,
  );
}

/**
 * List entries in a collection
 * GET /api/cms/collections/:collection
 * Supports both Markdown and YAML data collections
 */
export async function handleListEntries(
  _request: Request,
  collection: string,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  const context = getRepoContext(config);

  // Detect collection format
  const format = await detectCollectionFormat(locals.githubToken, context, collection);

  if (format === 'yaml') {
    try {
      const entries = await listYamlEntries(locals.githubToken, context, collection);
      return jsonResponse({ entries });
    } catch (error) {
      console.error('[SaastroCMS] YAML list error:', error);
      return jsonResponse(
        {
          error: 'internal_error',
          message: error instanceof Error ? error.message : 'Failed to list',
        },
        500,
      );
    }
  }

  // Fallback: Markdown via core service
  const service = createContentService(locals.githubToken, context);
  const result = await service.list(collection);

  if (!result.success) {
    return errorResponse(result.error);
  }

  return jsonResponse({ entries: result.data });
}

/**
 * Get a single entry
 * GET /api/cms/collections/:collection/:slug
 * Supports both Markdown and YAML data collections
 */
export async function handleGetEntry(
  _request: Request,
  collection: string,
  slug: string,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  const context = getRepoContext(config);

  // Try YAML first
  try {
    const yamlResult = await getYamlEntry(locals.githubToken, context, collection, slug);
    if (yamlResult) {
      return jsonResponse(yamlResult);
    }
  } catch {
    // Fall through to MD
  }

  // Fallback: Markdown via core service (.md)
  const service = createContentService(locals.githubToken, context);
  const result = await service.get(collection, slug);

  if (result.success) {
    return jsonResponse({ entry: result.data });
  }

  // Try .mdx if .md failed
  try {
    const mdxPath = `${context.contentPath}/${collection}/${slug}.mdx`;
    const resp = await fetch(
      `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(mdxPath)}?ref=${context.branch}`,
      {
        headers: {
          Authorization: `Bearer ${locals.githubToken}`,
          Accept: 'application/vnd.github.v3+json',
          'User-Agent': 'SaastroCMS/1.0',
        },
      },
    );
    if (resp.ok) {
      const data = (await resp.json()) as { content: string; sha: string; path: string };
      const raw = decodeBase64(data.content);
      const { frontmatter, body } = parseFrontmatter(raw);
      return jsonResponse({
        entry: {
          slug,
          collection,
          path: data.path,
          sha: data.sha,
          frontmatter,
          body,
        },
      });
    }
  } catch {
    // Fall through
  }

  return errorResponse(result.error);
}

/**
 * Create a new entry
 * POST /api/cms/collections/:collection
 * Supports both Markdown and YAML data collections
 */
export async function handleCreateEntry(
  request: Request,
  collection: string,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  const body = (await parseJsonBody(request)) as {
    slug?: string;
    frontmatter?: Record<string, unknown>;
    body?: string;
    format?: 'yaml' | 'md';
  };

  const context = getRepoContext(config);

  // If format is explicitly yaml or auto-detected
  const format =
    body.format ?? (await detectCollectionFormat(locals.githubToken, context, collection));

  if (format === 'yaml') {
    const slug = body.slug;
    const frontmatter = body.frontmatter;
    if (!slug || !frontmatter) {
      return jsonResponse(
        { error: 'validation_error', message: 'slug and frontmatter are required' },
        400,
      );
    }

    try {
      const result = await createYamlEntry(
        locals.githubToken,
        context,
        collection,
        slug,
        frontmatter,
      );

      return jsonResponse(
        { entry: { slug, collection, path: result.path, sha: result.sha, frontmatter, body: '' } },
        201,
      );
    } catch (error) {
      return jsonResponse(
        {
          error: 'internal_error',
          message: error instanceof Error ? error.message : 'Failed to create',
        },
        500,
      );
    }
  }

  // Fallback: Markdown via core service
  const parsed = createContentRequestSchema.safeParse(body);
  if (!parsed.success) {
    return jsonResponse(
      {
        error: 'validation_error',
        message: 'Invalid request body',
        details: parsed.error.flatten(),
      },
      400,
    );
  }

  const service = createContentService(locals.githubToken, context);
  const result = await service.create({
    collection,
    slug: parsed.data.slug,
    frontmatter: parsed.data.frontmatter,
    body: parsed.data.body,
  });

  if (!result.success) {
    return errorResponse(result.error);
  }

  return jsonResponse({ entry: result.data }, 201);
}

/**
 * Update an existing entry
 * PUT /api/cms/collections/:collection/:slug
 * Supports both Markdown and YAML data collections
 */
export async function handleUpdateEntry(
  request: Request,
  collection: string,
  slug: string,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  const body = (await parseJsonBody(request)) as {
    sha?: string;
    frontmatter?: Record<string, unknown>;
    body?: string;
    format?: 'yaml' | 'md';
    newSlug?: string;
  };

  const context = getRepoContext(config);

  // Detect format: try YAML first
  const ext = await resolveFileExtension(locals.githubToken, context, collection, slug);
  const isYaml = ext === 'yaml' || ext === 'yml' || body.format === 'yaml';

  // Handle slug rename (create at new path, delete old file)
  if (body.newSlug && body.newSlug !== slug) {
    const newSlug = body.newSlug;
    const sha = body.sha;
    const frontmatter = body.frontmatter;
    if (!sha || !frontmatter) {
      return jsonResponse(
        { error: 'validation_error', message: 'sha and frontmatter are required' },
        400,
      );
    }

    // Verify new slug doesn't already exist
    for (const checkExt of ['yaml', 'yml', 'mdx', 'md'] as const) {
      const checkPath = `${context.contentPath}/${collection}/${newSlug}.${checkExt}`;
      const checkResp = await fetch(
        `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(checkPath)}?ref=${context.branch}`,
        {
          headers: {
            Authorization: `Bearer ${locals.githubToken}`,
            Accept: 'application/vnd.github.v3+json',
            'User-Agent': 'SaastroCMS/1.0',
          },
        },
      );
      if (checkResp.ok) {
        return jsonResponse(
          { error: 'conflict', message: `Slug "${newSlug}" already exists in ${collection}` },
          409,
        );
      }
    }

    try {
      let newPath: string;
      let newSha: string;

      if (isYaml) {
        const result = await createYamlEntry(
          locals.githubToken,
          context,
          collection,
          newSlug,
          frontmatter,
        );
        newPath = result.path;
        newSha = result.sha;
      } else if (ext === 'mdx') {
        const filePath = `${context.contentPath}/${collection}/${newSlug}.mdx`;
        const fmStr = yaml.dump(frontmatter, { indent: 2, lineWidth: -1, noRefs: true }).trim();
        const fileContent = `---\n${fmStr}\n---\n\n${body.body || ''}`;
        const createResp = await fetch(
          `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(filePath)}`,
          {
            method: 'PUT',
            headers: {
              Authorization: `Bearer ${locals.githubToken}`,
              Accept: 'application/vnd.github.v3+json',
              'Content-Type': 'application/json',
              'User-Agent': 'SaastroCMS/1.0',
            },
            body: JSON.stringify({
              message: `content: rename ${collection}/${slug} to ${newSlug}`,
              content: encodeBase64(fileContent),
              branch: context.branch,
            }),
          },
        );
        if (!createResp.ok) {
          const err = (await createResp.json()) as { message?: string };
          throw new Error(err.message || 'Failed to create at new slug');
        }
        const result = (await createResp.json()) as { content: { sha: string; path: string } };
        newPath = result.content.path;
        newSha = result.content.sha;
      } else {
        const service = createContentService(locals.githubToken, context);
        const result = await service.create({
          collection,
          slug: newSlug,
          frontmatter,
          body: body.body || '',
        });
        if (!result.success) return errorResponse(result.error);
        newPath = result.data.path;
        newSha = result.data.sha;
      }

      // Delete old file
      try {
        await deleteEntryFile(locals.githubToken, context, collection, slug, sha, ext);
      } catch (deleteError) {
        // Old file deletion failed but new file already exists.
        // Return partial success so the client can navigate to the new slug.
        console.warn(
          `[SaastroCMS] Rename: created ${newSlug} but failed to delete old ${slug}:`,
          deleteError,
        );
        return jsonResponse({
          entry: {
            slug: newSlug,
            collection,
            path: newPath,
            sha: newSha,
            frontmatter,
            body: body.body || '',
          },
          renamed: true,
          deleteOldFailed: true,
        });
      }

      return jsonResponse({
        entry: {
          slug: newSlug,
          collection,
          path: newPath,
          sha: newSha,
          frontmatter,
          body: body.body || '',
        },
        renamed: true,
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to rename';
      return jsonResponse({ error: 'internal_error', message }, 500);
    }
  }

  if (isYaml) {
    const sha = body.sha;
    const frontmatter = body.frontmatter;
    if (!sha || !frontmatter) {
      return jsonResponse(
        { error: 'validation_error', message: 'sha and frontmatter are required' },
        400,
      );
    }

    try {
      const result = await updateYamlEntry(
        locals.githubToken,
        context,
        collection,
        slug,
        sha,
        frontmatter,
      );

      return jsonResponse({
        entry: { slug, collection, path: result.path, sha: result.sha, frontmatter, body: '' },
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to update';
      if (message.includes('SHA') || message.includes('409')) {
        return jsonResponse(
          { error: 'conflict', message: 'Content was modified. Please refresh and try again.' },
          409,
        );
      }
      return jsonResponse({ error: 'internal_error', message }, 500);
    }
  }

  // MDX or MD: serialize frontmatter + body
  const sha = body.sha;
  const frontmatter = body.frontmatter;
  const mdBody = body.body ?? '';
  if (!sha || !frontmatter) {
    return jsonResponse(
      { error: 'validation_error', message: 'sha and frontmatter are required' },
      400,
    );
  }

  // For .mdx files, write directly via GitHub API (core service only handles .md)
  if (ext === 'mdx') {
    try {
      const filePath = `${context.contentPath}/${collection}/${slug}.mdx`;
      const fmStr = yaml.dump(frontmatter, { indent: 2, lineWidth: -1, noRefs: true }).trim();
      const content = `---\n${fmStr}\n---\n\n${mdBody}`;
      const resp = await fetch(
        `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(filePath)}`,
        {
          method: 'PUT',
          headers: {
            Authorization: `Bearer ${locals.githubToken}`,
            Accept: 'application/vnd.github.v3+json',
            'User-Agent': 'SaastroCMS/1.0',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: `Update ${collection}/${slug}`,
            content: encodeBase64(content),
            sha,
            branch: context.branch,
          }),
        },
      );
      if (!resp.ok) {
        const errData = (await resp.json()) as { message?: string };
        if (resp.status === 409) {
          return jsonResponse(
            { error: 'conflict', message: 'Content was modified. Please refresh and try again.' },
            409,
          );
        }
        return jsonResponse(
          { error: 'internal_error', message: errData.message || 'Failed to update' },
          500,
        );
      }
      const resData = (await resp.json()) as { content: { sha: string; path: string } };

      return jsonResponse({
        entry: {
          slug,
          collection,
          path: resData.content.path,
          sha: resData.content.sha,
          frontmatter,
          body: mdBody,
        },
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to update';
      return jsonResponse({ error: 'internal_error', message }, 500);
    }
  }

  // Fallback: .md via core service
  const parsed = updateContentRequestSchema.safeParse(body);
  if (!parsed.success) {
    return jsonResponse(
      {
        error: 'validation_error',
        message: 'Invalid request body',
        details: parsed.error.flatten(),
      },
      400,
    );
  }

  const service = createContentService(locals.githubToken, context);
  const result = await service.update({
    collection,
    slug,
    sha: parsed.data.sha,
    frontmatter: parsed.data.frontmatter,
    body: parsed.data.body,
  });

  if (!result.success) {
    return errorResponse(result.error);
  }

  return jsonResponse({ entry: result.data });
}

/**
 * Delete an entry
 * DELETE /api/cms/collections/:collection/:slug
 */
export async function handleDeleteEntry(
  request: Request,
  collection: string,
  slug: string,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  const body = (await parseJsonBody(request)) as { sha?: string };
  if (!body.sha) {
    return jsonResponse({ error: 'validation_error', message: 'sha is required' }, 400);
  }

  const context = getRepoContext(config);

  // Detect file format to use the right delete method
  const ext = await resolveFileExtension(locals.githubToken, context, collection, slug);
  const isYaml = ext === 'yaml' || ext === 'yml';

  try {
    if (isYaml || ext === 'mdx') {
      // YAML and MDX: delete directly via GitHub Contents API
      await deleteEntryFile(locals.githubToken, context, collection, slug, body.sha, ext);
      return jsonResponse({ deleted: true });
    }

    // Fallback: .md via core service
    const service = createContentService(locals.githubToken, context);
    const result = await service.delete({ collection, slug, sha: body.sha });
    if (!result.success) return errorResponse(result.error);
    return jsonResponse({ deleted: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to delete';
    return jsonResponse({ error: 'internal_error', message }, 500);
  }
}

/**
 * Get revision history for an entry
 * GET /api/cms/collections/:collection/:slug/revisions
 */
export async function handleGetRevisions(
  _request: Request,
  collection: string,
  slug: string,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  const context = getRepoContext(config);

  // Resolve file extension (YAML or MD)
  const ext = await resolveFileExtension(locals.githubToken, context, collection, slug);
  const filePath = `${context.contentPath}/${collection}/${slug}.${ext}`;

  try {
    // Use GitHub API to get commit history for this file
    const response = await fetch(
      `https://api.github.com/repos/${context.owner}/${context.repo}/commits?path=${encodeURIComponent(filePath)}&sha=${context.branch}`,
      {
        headers: {
          Authorization: `Bearer ${locals.githubToken}`,
          Accept: 'application/vnd.github.v3+json',
        },
      },
    );

    if (!response.ok) {
      if (response.status === 404) {
        return jsonResponse({ revisions: [] });
      }
      throw new Error(`GitHub API error: ${response.status}`);
    }

    const commits = (await response.json()) as Array<{
      sha: string;
      commit: {
        message: string;
        author: {
          name: string;
          email: string;
          date: string;
        };
      };
      author?: {
        avatar_url: string;
      };
    }>;

    const revisions = commits.map((commit) => ({
      sha: commit.sha,
      message: commit.commit.message,
      author: {
        name: commit.commit.author.name,
        email: commit.commit.author.email,
        avatarUrl: commit.author?.avatar_url,
      },
      date: commit.commit.author.date,
    }));

    return jsonResponse({ revisions });
  } catch (error) {
    console.error('[SaastroCMS] Failed to get revisions:', error);
    return jsonResponse(
      {
        error: 'internal_error',
        message: error instanceof Error ? error.message : 'Failed to get revisions',
      },
      500,
    );
  }
}

/**
 * Get content at a specific revision
 * GET /api/cms/collections/:collection/:slug/revisions/:sha
 */
export async function handleGetRevisionContent(
  _request: Request,
  collection: string,
  slug: string,
  sha: string,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  const context = getRepoContext(config);

  // Resolve file extension (YAML or MD)
  const ext = await resolveFileExtension(locals.githubToken, context, collection, slug);
  const filePath = `${context.contentPath}/${collection}/${slug}.${ext}`;
  const isYaml = ext === 'yaml' || ext === 'yml';

  try {
    // Get file content at specific commit
    const response = await fetch(
      `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(filePath)}?ref=${sha}`,
      {
        headers: {
          Authorization: `Bearer ${locals.githubToken}`,
          Accept: 'application/vnd.github.v3+json',
        },
      },
    );

    if (!response.ok) {
      if (response.status === 404) {
        return jsonResponse({ error: 'not_found', message: 'Revision not found' }, 404);
      }
      throw new Error(`GitHub API error: ${response.status}`);
    }

    const data = (await response.json()) as {
      content: string;
      encoding: string;
    };

    // Decode base64 content
    const rawContent = decodeBase64(data.content);

    // For YAML data files, parse as pure YAML
    if (isYaml) {
      const { frontmatter } = parseYamlContent(rawContent);
      return jsonResponse({ content: { frontmatter, body: '' } });
    }

    // Parse frontmatter and body (Markdown)
    const frontmatterMatch = rawContent.match(/^---\n([\s\S]*?)\n---\n([\s\S]*)$/);
    if (!frontmatterMatch) {
      return jsonResponse({
        content: {
          frontmatter: {},
          body: rawContent,
        },
      });
    }

    // Simple YAML parsing for frontmatter
    const frontmatterStr = frontmatterMatch[1] ?? '';
    const bodyStr = frontmatterMatch[2] ?? '';
    const frontmatter: Record<string, unknown> = {};

    for (const line of frontmatterStr.split('\n')) {
      const colonIndex = line.indexOf(':');
      if (colonIndex > 0) {
        const key = line.slice(0, colonIndex).trim();
        let value: unknown = line.slice(colonIndex + 1).trim();

        // Try to parse as JSON for complex values
        if (value === 'true') value = true;
        else if (value === 'false') value = false;
        else if (!Number.isNaN(Number(value)) && value !== '') value = Number(value);
        else if ((value as string).startsWith('"') && (value as string).endsWith('"')) {
          value = (value as string).slice(1, -1);
        }

        frontmatter[key] = value;
      }
    }

    return jsonResponse({
      content: {
        frontmatter,
        body: bodyStr,
      },
    });
  } catch (error) {
    console.error('[SaastroCMS] Failed to get revision content:', error);
    return jsonResponse(
      {
        error: 'internal_error',
        message: error instanceof Error ? error.message : 'Failed to get revision content',
      },
      500,
    );
  }
}

/**
 * Get layout config for a collection
 * GET /api/cms/collections/:collection/layout
 */
export async function handleGetLayout(
  _request: Request,
  collection: string,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  const context = getRepoContext(config);
  const layoutPath = `${context.contentPath}/.saastrocms/layouts/${collection}.json`;

  try {
    const response = await fetch(
      `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(layoutPath)}?ref=${context.branch}`,
      {
        headers: {
          Authorization: `Bearer ${locals.githubToken}`,
          Accept: 'application/vnd.github.v3+json',
          'User-Agent': 'SaastroCMS/1.0',
        },
      },
    );

    if (!response.ok) {
      if (response.status === 404) {
        return jsonResponse({ layout: null });
      }
      throw new Error(`GitHub API error: ${response.status}`);
    }

    const data = (await response.json()) as { content: string; sha: string };
    const content = decodeBase64(data.content);
    const layout = JSON.parse(content);

    return jsonResponse({ layout, sha: data.sha });
  } catch (error) {
    console.error('[SaastroCMS] Failed to get layout:', error);
    return jsonResponse(
      {
        error: 'internal_error',
        message: error instanceof Error ? error.message : 'Failed to get layout',
      },
      500,
    );
  }
}

/**
 * Save layout config for a collection
 * PUT /api/cms/collections/:collection/layout
 */
export async function handleSaveLayout(
  request: Request,
  collection: string,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  const body = (await parseJsonBody(request)) as { layout: unknown; sha?: string };
  if (!body.layout) {
    return jsonResponse({ error: 'validation_error', message: 'layout is required' }, 400);
  }

  const context = getRepoContext(config);
  const layoutPath = `${context.contentPath}/.saastrocms/layouts/${collection}.json`;
  const content = encodeBase64(JSON.stringify(body.layout, null, 2));

  try {
    const payload: Record<string, unknown> = {
      message: `chore: update ${collection} form layout`,
      content,
      branch: context.branch,
    };
    if (body.sha) payload.sha = body.sha;

    const response = await fetch(
      `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(layoutPath)}`,
      {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${locals.githubToken}`,
          Accept: 'application/vnd.github.v3+json',
          'Content-Type': 'application/json',
          'User-Agent': 'SaastroCMS/1.0',
        },
        body: JSON.stringify(payload),
      },
    );

    if (!response.ok) {
      const err = (await response.json()) as { message?: string };
      throw new Error(err.message || `GitHub API error: ${response.status}`);
    }

    const result = (await response.json()) as { content: { sha: string } };
    return jsonResponse({ saved: true, sha: result.content.sha });
  } catch (error) {
    console.error('[SaastroCMS] Failed to save layout:', error);
    return jsonResponse(
      {
        error: 'internal_error',
        message: error instanceof Error ? error.message : 'Failed to save layout',
      },
      500,
    );
  }
}

/**
 * Check if a slug is available in a collection
 * GET /api/cms/collections/:collection/check-slug?slug=xxx&exclude=yyy
 */
export async function handleCheckSlug(
  request: Request,
  collection: string,
  locals: SaastroCMSLocals,
  config: SaastroCMSConfig,
): Promise<Response> {
  if (!locals.githubToken) {
    return jsonResponse({ error: 'unauthorized', message: 'Not authenticated' }, 401);
  }

  const url = new URL(request.url);
  const slug = url.searchParams.get('slug');
  const exclude = url.searchParams.get('exclude');

  if (!slug) {
    return jsonResponse({ error: 'validation_error', message: 'slug parameter is required' }, 400);
  }

  // If checking the current entry's own slug, it's always available
  if (exclude && slug === exclude) {
    return jsonResponse({ available: true });
  }

  const context = getRepoContext(config);

  // Check if a file with this slug exists (try all extensions)
  for (const ext of ['yaml', 'yml', 'mdx', 'md']) {
    const path = `${context.contentPath}/${collection}/${slug}.${ext}`;
    const resp = await fetch(
      `https://api.github.com/repos/${context.owner}/${context.repo}/contents/${encodeURIComponent(path)}?ref=${context.branch}`,
      {
        headers: {
          Authorization: `Bearer ${locals.githubToken}`,
          Accept: 'application/vnd.github.v3+json',
          'User-Agent': 'SaastroCMS/1.0',
        },
      },
    );
    if (resp.ok) {
      return jsonResponse({ available: false });
    }
  }

  return jsonResponse({ available: true });
}

/**
 * Route handler for content API endpoints
 * Matches: /api/cms/collections/:collection and /api/cms/collections/:collection/:slug
 */
export async function handleContentRequest(
  request: Request,
  locals: { saastrocms: SaastroCMSLocals },
  config: SaastroCMSConfig,
): Promise<Response | null> {
  // Only run the guard for /api/cms/collections/* (our concern).
  // Non-content requests fall through to return null so other handlers match.
  if (!new URL(request.url).pathname.startsWith('/api/cms/collections/')) {
    return null;
  }

  // Auth guard — blocks CSRF + unauthenticated writes.
  const guard = guardCMSRequest(
    request,
    locals as { saastrocms: { session: unknown; githubToken: string | null } },
    config,
  );
  if (!guard.allowed) return guard.response;

  // In dev mode, use local filesystem instead of GitHub API
  if (config._localContentRoot) {
    const { handleContentRequestLocal } = await import('./local-content.js');
    return handleContentRequestLocal(request, config._localContentRoot, config);
  }

  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  // Extract and validate path segments early
  const collectionsPrefix = '/api/cms/collections/';
  if (path.startsWith(collectionsPrefix)) {
    const rest = path.slice(collectionsPrefix.length);
    const segments = rest.split('/').filter(Boolean);
    for (const seg of segments) {
      // Skip known route keywords
      if (['check-slug', 'layout', 'revisions'].includes(seg)) continue;
      if (!isValidPathSegment(seg)) {
        return jsonResponse(
          { error: 'validation_error', message: `Invalid path segment: "${seg}"` },
          400,
        );
      }
    }
  }

  // Match /api/cms/collections/:collection/check-slug
  const checkSlugMatch = path.match(/^\/api\/cms\/collections\/([^/]+)\/check-slug$/);
  if (checkSlugMatch && checkSlugMatch[1]) {
    const collection = checkSlugMatch[1];
    if (method === 'GET') {
      return handleCheckSlug(request, collection, locals.saastrocms, config);
    }
    return jsonResponse({ error: 'method_not_allowed', message: 'Method not allowed' }, 405);
  }

  // Match /api/cms/collections/:collection/layout
  const layoutMatch = path.match(/^\/api\/cms\/collections\/([^/]+)\/layout$/);
  if (layoutMatch && layoutMatch[1]) {
    const collection = layoutMatch[1];
    try {
      if (method === 'GET') {
        return handleGetLayout(request, collection, locals.saastrocms, config);
      }
      if (method === 'PUT') {
        return handleSaveLayout(request, collection, locals.saastrocms, config);
      }
      return jsonResponse({ error: 'method_not_allowed', message: 'Method not allowed' }, 405);
    } catch (error) {
      console.error('[SaastroCMS] Layout API error:', error);
      return jsonResponse(
        {
          error: 'internal_error',
          message: error instanceof Error ? error.message : 'Internal server error',
        },
        500,
      );
    }
  }

  // Match /api/cms/collections/:collection/:slug/revisions/:sha?
  const revisionMatch = path.match(
    /^\/api\/cms\/collections\/([^/]+)\/([^/]+)\/revisions(?:\/([^/]+))?$/,
  );
  if (revisionMatch && revisionMatch[1] && revisionMatch[2]) {
    const collection = revisionMatch[1];
    const slug = revisionMatch[2];
    const sha = revisionMatch[3] as string | undefined;

    try {
      if (method === 'GET') {
        if (sha) {
          return handleGetRevisionContent(
            request,
            collection,
            slug,
            sha,
            locals.saastrocms,
            config,
          );
        }
        return handleGetRevisions(request, collection, slug, locals.saastrocms, config);
      }
      return jsonResponse({ error: 'method_not_allowed', message: 'Method not allowed' }, 405);
    } catch (error) {
      console.error('[SaastroCMS] Revision API error:', error);
      return jsonResponse(
        {
          error: 'internal_error',
          message: error instanceof Error ? error.message : 'Internal server error',
        },
        500,
      );
    }
  }

  // Match /api/cms/collections/:collection/:slug?
  const match = path.match(/^\/api\/cms\/collections\/([^/]+)(?:\/([^/]+))?$/);
  if (!match || !match[1]) {
    return null;
  }

  const collection = match[1];
  const slug = match[2] as string | undefined;

  try {
    // Collection-level operations
    if (!slug) {
      if (method === 'GET') {
        return handleListEntries(request, collection, locals.saastrocms, config);
      }
      if (method === 'POST') {
        return handleCreateEntry(request, collection, locals.saastrocms, config);
      }
      return jsonResponse({ error: 'method_not_allowed', message: 'Method not allowed' }, 405);
    }

    // Entry-level operations
    if (method === 'GET') {
      return handleGetEntry(request, collection, slug, locals.saastrocms, config);
    }
    if (method === 'PUT') {
      return handleUpdateEntry(request, collection, slug, locals.saastrocms, config);
    }
    if (method === 'DELETE') {
      return handleDeleteEntry(request, collection, slug, locals.saastrocms, config);
    }

    return jsonResponse({ error: 'method_not_allowed', message: 'Method not allowed' }, 405);
  } catch (error) {
    if (error instanceof ContentError) {
      return errorResponse(error);
    }
    console.error('[SaastroCMS] Content API error:', error);
    return jsonResponse(
      {
        error: 'internal_error',
        message: error instanceof Error ? error.message : 'Internal server error',
      },
      500,
    );
  }
}
