/**
 * SaastroCMS Authentication Middleware
 * Protects /admin/* and /api/cms/* routes
 */

import {
  type SessionData,
  type SessionStorage,
  getDecryptedToken,
  getSession,
  parseSessionCookie,
} from '@saastro/core/auth';
import type { MiddlewareHandler } from 'astro';
import type { CloudflareEnv } from './types.js';

/**
 * Session data available in Astro.locals
 */
export type SaastroCMSLocals = {
  session: SessionData | null;
  githubToken: string | null;
};

/**
 * Paths that require authentication
 */
const PROTECTED_PATHS = ['/admin', '/api/cms'];

/**
 * Paths that are always public (auth endpoints)
 */
const PUBLIC_PATHS = ['/api/auth/login', '/api/auth/callback', '/api/auth/logout'];

/**
 * Check if a path requires authentication
 */
function isProtectedPath(pathname: string): boolean {
  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p))) {
    return false;
  }
  return PROTECTED_PATHS.some((p) => pathname.startsWith(p));
}

/**
 * Create a KV-compatible session storage from Cloudflare KV
 */
function createKVStorage(kv: KVNamespace): SessionStorage {
  return {
    async get(key: string): Promise<SessionData | null> {
      const data = await kv.get(key, 'json');
      return data as SessionData | null;
    },
    async put(
      key: string,
      value: SessionData,
      options?: { expirationTtl?: number },
    ): Promise<void> {
      await kv.put(key, JSON.stringify(value), {
        expirationTtl: options?.expirationTtl,
      });
    },
    async delete(key: string): Promise<void> {
      await kv.delete(key);
    },
  };
}

/**
 * Load session data from cookie and KV
 */
async function loadSession(
  cookieHeader: string | null,
  env: CloudflareEnv,
): Promise<SaastroCMSLocals> {
  const result: SaastroCMSLocals = { session: null, githubToken: null };

  const sessionId = parseSessionCookie(cookieHeader);
  if (!sessionId) {
    return result;
  }

  try {
    const storage = createKVStorage(env.KV);
    const session = await getSession(storage, sessionId);
    if (!session) {
      return result;
    }

    result.session = session;
    if (session.encryptedToken) {
      result.githubToken = await getDecryptedToken(session.encryptedToken, env.ENCRYPTION_KEY);
    }
  } catch (error) {
    console.error('[SaastroCMS] Session validation error:', error);
  }

  return result;
}

/**
 * Handle unauthorized access
 */
function handleUnauthorized(request: Request, url: URL): Response {
  const acceptHeader = request.headers.get('Accept') || '';

  if (acceptHeader.includes('text/html')) {
    const loginUrl = new URL('/api/auth/login', url.origin);
    loginUrl.searchParams.set('redirect', url.pathname);
    return Response.redirect(loginUrl.toString(), 302);
  }

  return new Response(JSON.stringify({ error: 'Unauthorized' }), {
    status: 401,
    headers: { 'Content-Type': 'application/json' },
  });
}

/**
 * Create the SaastroCMS authentication middleware
 */
export function createAuthMiddleware(): MiddlewareHandler {
  return async (context, next) => {
    const { request, locals } = context;
    const url = new URL(request.url);

    // Get Cloudflare runtime environment
    const runtime = (locals as { runtime?: { env: CloudflareEnv } }).runtime;
    if (!runtime?.env) {
      (locals as { saastrocms?: SaastroCMSLocals }).saastrocms = {
        session: null,
        githubToken: null,
      };
      return next();
    }

    // Load session
    const cookieHeader = request.headers.get('Cookie');
    const saastrocmsLocals = await loadSession(cookieHeader, runtime.env);
    (locals as { saastrocms: SaastroCMSLocals }).saastrocms = saastrocmsLocals;

    // Check authentication for protected paths
    if (isProtectedPath(url.pathname) && !saastrocmsLocals.session) {
      return handleUnauthorized(request, url);
    }

    return next();
  };
}

/**
 * Default middleware export
 */
export const onRequest = createAuthMiddleware();
