declare module 'virtual:saastrocms/config' {
  import type { SaastroCMSConfig } from '../types.js';
  const config: SaastroCMSConfig;
  export default config;
}

declare module 'virtual:saastrocms/admin-css' {
  // CSS virtual module — imports project CSS for admin styling
}
