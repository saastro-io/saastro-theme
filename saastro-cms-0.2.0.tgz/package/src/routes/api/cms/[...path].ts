/**
 * Auto-injected CMS API Route
 *
 * Catch-all that delegates to existing content and media handlers.
 * Injected by @saastro/cms integration via `injectRoute`.
 *
 * Routes:
 * - /api/cms/collections/* → handleContentRequest
 * - /api/cms/media/*       → handleMediaRequest
 */

import type { APIRoute } from 'astro';
// @ts-ignore - virtual module provided by the CMS integration
import config from 'virtual:saastrocms/config';
import { handleContentRequest } from '../../../api/content.js';
import { handleMediaRequest } from '../../../api/media.js';
import { handleTranslationsRequest } from '../../../api/translations.js';
import type { SaastroCMSLocals } from '../../../middleware.js';

function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

/**
 * Resolve GitHub token from available sources:
 * 1. Astro locals (set by auth middleware)
 * 2. Environment variables (for token-based auth in standalone mode)
 */
function resolveGitHubToken(context: Parameters<APIRoute>[0]): string | null {
  // From auth middleware (OAuth flow)
  const locals = context.locals as Record<string, unknown>;
  const saastrocms = locals.saastrocms as { githubToken?: string | null } | undefined;
  if (saastrocms?.githubToken) {
    return saastrocms.githubToken;
  }

  // From environment variables (standalone token auth)
  const env = (locals.runtime as { env?: Record<string, string> } | undefined)?.env;
  if (env) {
    return env.CMS_GITHUB_TOKEN || env.GITHUB_TOKEN || null;
  }

  // Try import.meta.env (Astro env)
  try {
    const metaEnv = (import.meta as { env?: Record<string, string> }).env;
    return metaEnv?.CMS_GITHUB_TOKEN || metaEnv?.GITHUB_TOKEN || null;
  } catch {
    return null;
  }
}

export const ALL: APIRoute = async (context) => {
  const githubToken = resolveGitHubToken(context);

  // In local dev mode, GitHub token is not required for content operations
  if (!githubToken && !config._localContentRoot) {
    return jsonResponse(
      {
        error: 'unauthorized',
        message: 'GitHub token not found. Configure auth middleware or set GITHUB_TOKEN env var.',
      },
      401,
    );
  }

  // Preserve the session already attached by an upstream auth middleware.
  // The CMS guard uses this to distinguish authenticated requests from the
  // dev-mode loopback escape hatch.
  const existingLocals = context.locals as Record<string, unknown>;
  const existingSaastrocms = existingLocals.saastrocms as SaastroCMSLocals | undefined;

  const locals: { saastrocms: SaastroCMSLocals } = {
    saastrocms: {
      session: existingSaastrocms?.session ?? null,
      githubToken: githubToken ?? '',
    },
  };

  // Settings API is handled by the Vite middleware in index.ts (needs node:fs).
  // It intercepts /api/cms/settings/* before this route handler runs.

  // Try translations handler (i18n)
  const translationsResponse = await handleTranslationsRequest(context.request, locals, config);
  if (translationsResponse) return translationsResponse;

  // Try content handler
  const contentResponse = await handleContentRequest(context.request, locals, config);
  if (contentResponse) return contentResponse;

  // Try media handler — local mode or GitHub mode
  if (config._localContentRoot) {
    const { handleMediaRequestLocal } = await import('../../../api/local-content.js');
    const mediaResponse = await handleMediaRequestLocal(
      context.request,
      config._localContentRoot,
      config,
    );
    if (mediaResponse) return mediaResponse;
  } else if (githubToken) {
    const mediaResponse = await handleMediaRequest(context.request, locals, config);
    if (mediaResponse) return mediaResponse;
  }

  return jsonResponse({ error: 'not_found', message: 'Unknown API route' }, 404);
};
