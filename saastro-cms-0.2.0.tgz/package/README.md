# @saastro/cms

Git-based CMS integration for [Astro](https://astro.build). Add a full-featured admin panel and REST API to any Astro site. Content is stored as Markdown in your GitHub repository.

## Installation

```bash
pnpm add @saastro/cms
```

**Peer dependencies:** `astro` ^4/^5, `react` ^18/^19, `react-dom` ^18/^19

## Quick Start

```typescript
// astro.config.ts
import saastrocms from '@saastro/cms';

export default defineConfig({
  integrations: [
    saastrocms({
      github: { owner: 'your-org', repo: 'your-site' },
    }),
  ],
});
```

This gives you:

- Admin panel at `/admin`
- REST API at `/api/cms/*`
- Visual editor support via `data-saastrocms-field` attributes

## Authentication

### GitHub OAuth (default)

```env
GITHUB_CLIENT_ID=...
GITHUB_CLIENT_SECRET=...
SESSION_SECRET=...
ENCRYPTION_KEY=...
```

### Token Auth

```typescript
import { createAltAuthMiddleware } from '@saastro/cms/auth';

createAltAuthMiddleware({
  method: 'token',
  token: { tokens: [{ token: 'secret', user: { id: '1', name: 'Admin', role: 'admin' } }] },
});
```

### Basic Auth / No Auth

```typescript
createAltAuthMiddleware({ method: 'basic', basic: { users: [...] } });
createAltAuthMiddleware({ method: 'none' }); // dev only
```

## Storage

```typescript
import { initStorage } from '@saastro/cms/storage';

// Production
initStorage({ type: 'github', github: { owner: '...', repo: '...', token: '...' } });

// Development
initStorage({ type: 'memory' });
```

## Collections

```typescript
import { defineCollection } from '@saastro/cms';
import { z } from 'zod';

const blog = defineCollection({
  name: 'blog',
  schema: z.object({ title: z.string(), date: z.coerce.date() }),
});
```

## Development

```bash
pnpm dev          # Watch mode
pnpm build        # Production build
pnpm test         # Run tests
pnpm typecheck    # Type checking
```

## License

MIT
